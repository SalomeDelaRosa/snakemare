# -*- coding: utf-8 -*-
"""
Lógica de una partida: tablero, serpiente, enemigos, objetos y niveles.
TODO lo aleatorio pasa por self.rngs, un generador por cada elemento del juego:
  rngs["tablero"]  -> obstáculos, portales, decoración, dónde aparecen los enemigos
  rngs["frutas"]   -> qué fruta sale, dónde aparece, veneno, velas, llave, almas
  rngs["enemigos"] -> movimiento de murciélagos, serpientes, calaveras y manos de esqueleto
  rngs["eventos"]  -> relámpagos, portales, bono sorteado, partículas, temblor
El jugador puede asignar un generador distinto a cada uno (incluso en plena partida).
"""
import math
from collections import deque

import pygame

import dibujo as D
from config import (CELDA, COLS, FILAS, HUD, PIE, ANCHO, ALTO, DIRS, DER, INICIO, ZONA_SEGURA,
                    DIFICULTADES, NIVELES, PUNTOS_VIDA_EXTRA, TEXTO, TENUE)


def dentro(c):
    return 0 <= c[0] < COLS and 0 <= c[1] < FILAS


def alcanzables(obstaculos, origen):
    """BFS: celdas a las que se puede llegar desde el origen."""
    vistos = {origen}
    cola = deque([origen])
    while cola:
        x, y = cola.popleft()
        for dx, dy in DIRS:
            c = (x + dx, y + dy)
            if dentro(c) and c not in obstaculos and c not in vistos:
                vistos.add(c)
                cola.append(c)
    return vistos


# ======================================================================
# GENERADOR DE TABLEROS (stages)
# ======================================================================
def generar_obstaculos(nivel, rng, extra):
    obs = set()
    if nivel == 1:                                    # lápidas sueltas
        cantidad = 16 + 3 * extra
        while len(obs) < cantidad:
            c = (rng.entero(1, COLS - 2), rng.entero(1, FILAS - 2))
            if c not in ZONA_SEGURA:
                obs.add(c)
    elif nivel == 2:                                  # grupos de barriles
        formas = [[(0, 0)], [(0, 0), (1, 0)], [(0, 0), (0, 1)], [(0, 0), (1, 0), (0, 1), (1, 1)],
                  [(0, 0), (1, 0), (2, 0)]]
        for _ in range(10 + 2 * extra):
            bx, by = rng.entero(1, COLS - 3), rng.entero(1, FILAS - 3)
            for dx, dy in rng.elegir(formas):
                c = (bx + dx, by + dy)
                if c not in ZONA_SEGURA:
                    obs.add(c)
    elif nivel == 3:                                  # muros de la mansión
        for _ in range(10 + 2 * extra):
            largo = rng.entero(3, 7)
            horizontal = rng.probabilidad(0.5)
            x0, y0 = rng.entero(1, COLS - 2), rng.entero(1, FILAS - 2)
            for k in range(largo):
                c = (x0 + k, y0) if horizontal else (x0, y0 + k)
                if dentro(c) and c not in ZONA_SEGURA:
                    obs.add(c)
    elif nivel == 4:                                  # nidos de huevos
        formas = [[(0, 0)], [(0, 0), (1, 0)], [(0, 0), (0, 1)], [(0, 0), (1, 0), (0, 1)]]
        for _ in range(9 + 2 * extra):
            bx, by = rng.entero(1, COLS - 3), rng.entero(1, FILAS - 3)
            for dx, dy in rng.elegir(formas):
                c = (bx + dx, by + dy)
                if c not in ZONA_SEGURA:
                    obs.add(c)
    else:                                             # pilares rúnicos de la cripta
        while len(obs) < 9 + extra:
            c = (rng.entero(1, COLS - 2), rng.entero(1, FILAS - 2))
            if c not in ZONA_SEGURA:
                obs.add(c)
    # Celdas encerradas -> también son obstáculo (así nada aparece donde no se puede llegar)
    alc = alcanzables(obs, INICIO[0])
    todas = {(x, y) for x in range(COLS) for y in range(FILAS)}
    obs |= todas - alc - obs
    return obs, alc


# ======================================================================
# ENEMIGOS
# ======================================================================
class Volador:
    """Murciélago o calavera flotante: caminata aleatoria en 8 direcciones."""

    def __init__(self, rng, x, y, vel, tipo):
        self.x, self.y, self.vel, self.tipo = x, y, vel, tipo
        self.cambiar(rng)

    def cambiar(self, rng):
        ang = math.radians(45 * rng.entero(0, 7))
        self.vx, self.vy = math.cos(ang) * self.vel, math.sin(ang) * self.vel
        self.t_cambio = rng.real(0.5, 1.8)

    def actualizar(self, dt, rng):
        self.t_cambio -= dt
        if self.t_cambio <= 0:
            self.cambiar(rng)
        self.x += self.vx * dt
        self.y += self.vy * dt
        if self.x < 0 or self.x > COLS - 1:
            self.vx = -self.vx
            self.x = max(0, min(COLS - 1, self.x))
        if self.y < 0 or self.y > FILAS - 1:
            self.vy = -self.vy
            self.y = max(0, min(FILAS - 1, self.y))


class SerpienteEnemiga:
    """zombi: deambula y a veces persigue | sombra: persigue más, solo se ven sus ojos
    vibora: las del nido; huyen cuando tienes el poder de la fruta carmesí
    jefe: rey esqueleto de la cripta, con ataques de furia en tiempos aleatorios."""

    def __init__(self, tipo, cuerpo, vel, p_persigue):
        self.tipo, self.cuerpo, self.vel, self.p = tipo, cuerpo, vel, p_persigue
        self.dir = (-1, 0)
        self.acum = 0.0
        self.furia = 0.0
        self.t_furia = 4.0
        self.muerta = False

    def actualizar(self, dt, partida):
        if self.tipo == "jefe":
            self.t_furia -= dt
            if self.t_furia <= 0:
                self.furia = 2.0
                self.t_furia = partida.rngs["enemigos"].exponencial(5.0) + 2
                partida.snd.play("risa")
                partida.aviso("¡El rey esqueleto se enfurece!", partida.cabeza(), (200, 120, 255))
            self.furia = max(0.0, self.furia - dt)
        vel = self.vel * (1.8 if self.furia > 0 else 1.0)
        if self.tipo == "vibora" and partida.poder > 0:
            vel *= 0.7                                # asustadas: más lentas
        self.acum += dt * vel
        while self.acum >= 1 and not self.muerta:
            self.acum -= 1
            self.paso(partida)

    def paso(self, p):
        r = p.rngs["enemigos"]
        hx, hy = self.cuerpo[0]
        reversa = (-self.dir[0], -self.dir[1])
        opciones = []
        for d in DIRS:
            if d == reversa:
                continue
            c = (hx + d[0], hy + d[1])
            if not dentro(c) or c in p.obstaculos or c in p.portales_set or c in self.cuerpo[:-1]:
                continue
            if any(c in e.cuerpo for e in p.enemigos if e is not self):
                continue
            opciones.append((d, c))
        if not opciones:                              # atrapada: se da la vuelta
            self.cuerpo.reverse()
            a, b = self.cuerpo[0], self.cuerpo[1]
            self.dir = (a[0] - b[0], a[1] - b[1])
            return
        cab = p.cabeza()
        if self.tipo == "vibora" and p.poder > 0:
            # Con el poder activo, las víboras huyen (80 %) o se mueven al azar
            if r.probabilidad(0.8):
                d, c = max(opciones, key=lambda o: abs(o[1][0] - cab[0]) + abs(o[1][1] - cab[1]))
            else:
                d, c = r.elegir(opciones)
            self.dir = d
            if c == cab or c in p.serp:               # chocó contra ti: la devoras
                p.devorar(self)
                return
            self.cuerpo.insert(0, c)
            self.cuerpo.pop()
            return
        if r.probabilidad(self.p):                    # persigue (Bernoulli)
            d, c = min(opciones, key=lambda o: abs(o[1][0] - cab[0]) + abs(o[1][1] - cab[1]))
        else:                                         # movimiento aleatorio
            d, c = r.elegir(opciones)
        self.dir = d
        if p.invul <= 0 and p.t_muerte <= 0:
            if c == cab:
                p.danio("¡Te mordió una serpiente!")
            elif c in p.serp:
                i = p.serp.index(c)
                if i <= 2:
                    p.danio("¡Te mordió una serpiente!")
                else:
                    p.cortar(i)
        self.cuerpo.insert(0, c)
        self.cuerpo.pop()


# ======================================================================
# PARTIDA
# ======================================================================
class Partida:
    def __init__(self, rngs, nombre_dif, sonidos, nombre_gen):
        self.rngs = dict(rngs)
        self.rng = self.rngs["eventos"]
        self.nombre_dif = nombre_dif
        self.dif = DIFICULTADES[nombre_dif]
        self.snd = sonidos
        self.nombre_gen = nombre_gen
        self.puntos = 0
        self.vidas = self.dif["vidas"]
        self.prox_vida = PUNTOS_VIDA_EXTRA
        self.llave = False
        self.nivel = 0
        self.nivel_max = 0
        self.supervivencia = self.dif.get("supervivencia", False)
        self.ronda = 0
        self.poder = 0.0
        self.premio_final = 0
        self.terminada = False
        self.evento = None
        self.shake = 0.0
        self.t_muerte = 0.0
        self.mensajes = []
        self.particulas = []

    # ------------------------------------------------------------------ nivel
    def iniciar_nivel(self, n):
        r, e = self.rngs["tablero"], self.dif["extra"]
        self.nivel = n
        self.ronda += 1
        self.nivel_max = max(self.nivel_max, n)
        self.meta = NIVELES[n]["meta"]
        self.comidos = 0
        self.evento = None
        self.obstaculos, self.alcance = generar_obstaculos(n, r, e)
        self.portales = []
        if n == 5:
            while len(self.portales) < 3:
                c = (r.entero(2, COLS - 3), r.entero(2, FILAS - 3))
                if (c in self.alcance and c not in ZONA_SEGURA and c not in self.obstaculos
                        and all(abs(c[0] - q[0]) + abs(c[1] - q[1]) >= 10 for q in self.portales)):
                    self.portales.append(c)
        self.portales_set = set(self.portales)
        self.fondo = D.construir_fondo(n, self.obstaculos, r)

        self.serp = list(INICIO)
        self.dir = DER
        self.cola = []
        self.crecer = 0
        self.acum = 0.0
        self.vel_extra = 0.0
        self.invul = 2.0
        self.veneno_t = 0.0
        self.items, self.enemigos, self.voladores, self.manos, self.nieblas = [], [], [], [], []
        self.luz = 120.0
        self.flash = 0.0
        self.t_rayo = self.rngs["eventos"].exponencial(6.0)
        self.t_mano = self.rngs["enemigos"].exponencial(4.5 - 0.8 * e)
        self.mensajes, self.particulas = [], []
        self.poder = 0.0
        self.t_fruta = 2.0
        self.reapariciones = []
        self.vel_vibora = 4.3 + 0.5 * e

        if n == 1:
            for _ in range(2 + e):
                self.agregar_volador("murcielago", 2.4 + 0.3 * e)
        elif n == 2:
            for _ in range(1 + e):
                self.agregar_serpiente("zombi", 5, 4.2 + 0.5 * e, 0.35)
            self.agregar_volador("murcielago", 2.6)
            for _ in range(5):
                self.nieblas.append([r.real(-150, ANCHO), r.real(HUD - 30, HUD + FILAS * CELDA - 80),
                                     r.real(12, 30) * r.elegir([-1, 1]), D.mancha_niebla(r)])
        elif n == 3:
            for _ in range(1 + e):
                self.agregar_serpiente("sombra", 6, 4.6 + 0.5 * e, 0.55)
            for _ in range(1 + e // 2):
                self.agregar_volador("murcielago", 2.8)
        elif n == 4:
            # Nido: víboras que solo se pueden devorar con la fruta carmesí
            for _ in range(2 + e):
                self.agregar_serpiente("vibora", 5, self.vel_vibora, 0.4)
        else:
            # Cripta: el nivel más difícil
            self.agregar_serpiente("jefe", 11, 4.6 + 0.5 * e, 0.6)
            self.agregar_serpiente("sombra", 6, 4.4 + 0.4 * e, 0.45)
            for _ in range(3 + e):
                self.agregar_volador("calavera", 2.9 + 0.3 * e)

        if n == 5:
            for _ in range(3):
                self.agregar_item("alma", self.vida_alma())
        else:
            self.nueva_comida()

    def agregar_volador(self, tipo, vel):
        t = self.rngs["tablero"]
        x, y = t.real(14, COLS - 2), t.real(1, FILAS - 2)
        self.voladores.append(Volador(self.rngs["enemigos"], x, y, vel, tipo))

    def agregar_serpiente(self, tipo, largo, vel, p, lejos=False):
        for _ in range(300):
            t = self.rngs["tablero"]
            if lejos:                                 # reaparece en cualquier lugar, lejos de ti
                x, y = t.entero(1, COLS - largo - 1), t.entero(1, FILAS - 2)
            else:
                x, y = t.entero(13, COLS - largo - 1), t.entero(1, FILAS - 2)
            cuerpo = [(x + i, y) for i in range(largo)]
            cx, cy = self.serp[0] if lejos else (0, 0)
            if lejos and any(abs(c[0] - cx) + abs(c[1] - cy) < 8 or c in self.serp for c in cuerpo):
                continue
            if all(c in self.alcance and c not in self.obstaculos and c not in self.portales_set
                   and not any(c in en.cuerpo for en in self.enemigos) for c in cuerpo):
                self.enemigos.append(SerpienteEnemiga(tipo, cuerpo, vel, p))
                return

    def cambiar_generador(self, categoria, generador):
        """Cambia el generador de un elemento en plena partida."""
        self.rngs[categoria] = generador
        if categoria == "eventos":
            self.rng = generador

    # ------------------------------------------------------------------ utilidades
    def cabeza(self):
        return self.serp[0]

    def ocupadas(self):
        occ = set(self.obstaculos) | set(self.serp) | self.portales_set
        for en in self.enemigos:
            occ.update(en.cuerpo)
        for it in self.items:
            occ.add(it["pos"])
        for m in self.manos:
            occ.add(m["pos"])
        return occ

    def celda_libre(self, dist_min=3, rng=None):
        rng = rng or self.rngs["frutas"]
        occ = self.ocupadas()
        cx, cy = self.cabeza()
        candidatas = [c for c in self.alcance if c not in occ and abs(c[0] - cx) + abs(c[1] - cy) >= dist_min]
        return rng.elegir(candidatas) if candidatas else None

    def agregar_item(self, tipo, vida=None):
        c = self.celda_libre()
        if c:
            self.items.append(dict(pos=c, tipo=tipo, vida=vida, max=vida or 1))

    def vida_alma(self):
        """En la cripta las almas duran poco: entre 4 y 7 segundos."""
        return self.rngs["frutas"].real(4, 7)

    def nueva_comida(self):
        tipo = self.rngs["frutas"].elegir_ponderado(["calabaza", "caramelo"], [0.72, 0.28])   # discreta
        self.agregar_item(tipo, self.rngs["frutas"].real(6, 10))   # aparece y luego se esfuma

    def extras_al_comer(self):
        r = self.rngs["frutas"]
        tipos = [it["tipo"] for it in self.items]
        if self.nivel != 5 and "veneno" not in tipos and r.probabilidad(self.dif["veneno"]):
            self.agregar_item("veneno", 9.0)
        if self.nivel == 3:
            if tipos.count("vela") < 2 and r.probabilidad(0.4):
                self.agregar_item("vela", 14.0)
            if not self.supervivencia and not self.llave and "llave" not in tipos and r.probabilidad(0.12):
                self.agregar_item("llave", 11.0)
                self.snd.play("risa")
                self.aviso("Algo brilla en la oscuridad...", self.cabeza(), (200, 120, 255))

    def aviso(self, txt, celda, color=TEXTO, dur=1.6):
        x, y = D.px(celda)
        self.mensajes.append([txt, x, y - 14, dur, color])

    def particulas_en(self, celda, color, n=14):
        x, y = D.px(celda)
        for _ in range(n):
            ang = self.rng.real(0, 2 * math.pi)
            v = self.rng.real(30, 140)
            self.particulas.append([x, y, math.cos(ang) * v, math.sin(ang) * v, self.rng.real(0.3, 0.8), color])

    def sumar(self, pts, celda=None, color=(255, 220, 90)):
        pts = int(pts * self.dif["mult"])
        self.puntos += pts
        if celda and pts:
            self.aviso(f"+{pts}", celda, color, 0.9)
        while self.puntos >= self.prox_vida:
            self.vidas += 1
            self.prox_vida += PUNTOS_VIDA_EXTRA
            self.snd.play("vida")
            self.aviso("¡Vida extra!", self.cabeza(), (140, 255, 140))

    # ------------------------------------------------------------------ control
    def girar(self, d):
        if self.veneno_t > 0:                         # veneno: controles invertidos
            d = (-d[0], -d[1])
        ultima = self.cola[-1] if self.cola else self.dir
        if d == ultima or d == (-ultima[0], -ultima[1]):
            return
        if len(self.cola) < 2:
            self.cola.append(d)

    def velocidad(self):
        if self.supervivencia:                             # sube con cada ronda superada
            return self.dif["vel"] + 0.5 * min(self.ronda - 1, 6) + self.vel_extra
        return self.dif["vel"] + 0.6 * (self.nivel - 1) + self.vel_extra

    # ------------------------------------------------------------------ daño
    def danio(self, motivo):
        if self.t_muerte > 0:
            return
        self.vidas -= 1
        self.snd.play("golpe")
        self.shake = 0.45
        self.particulas_en(self.cabeza(), (230, 40, 60), 26)
        self.aviso(motivo, self.cabeza(), (255, 110, 110), 2.0)
        if self.vidas <= 0:
            self.t_muerte = 1.6
            return
        self.reaparecer()

    def reaparecer(self):
        peligro = set(self.obstaculos) | self.portales_set
        for en in self.enemigos:
            peligro.update(en.cuerpo)
        for m in self.manos:
            peligro.add(m["pos"])

        def libre(fila):
            return all(c in self.alcance and c not in peligro for c in fila)

        fila = list(INICIO) + [(x, 10) for x in range(6, 10)]
        if libre(fila):
            self.serp = list(INICIO)
        else:
            self.serp = list(INICIO)
            for _ in range(400):
                x, y = self.rngs["tablero"].entero(4, COLS - 9), self.rngs["tablero"].entero(1, FILAS - 2)
                if libre([(x - i, y) for i in range(4)] + [(x + i, y) for i in range(1, 5)]):
                    self.serp = [(x - i, y) for i in range(4)]
                    break
        self.dir = DER
        self.cola = []
        self.crecer = 0
        self.acum = 0.0
        self.invul = 3.0                                  # mismo tiempo que parpadea
        self.veneno_t = 0.0

    def cortar(self, i):
        perdidos = len(self.serp) - i
        self.serp = self.serp[:i]
        self.snd.play("corte")
        self.particulas_en(self.serp[-1], (120, 200, 90), 10)
        self.aviso(f"¡Te arrancaron {perdidos} segmentos!", self.cabeza(), (255, 160, 120))

    # ------------------------------------------------------------------ comer
    def comer(self, pos):
        for it in list(self.items):
            if it["pos"] != pos:
                continue
            self.items.remove(it)
            t = it["tipo"]
            if t in ("calabaza", "caramelo", "alma"):
                puntos = {"calabaza": 10, "caramelo": 25, "alma": 30}[t]
                self.sumar(puntos, pos)
                self.crecer += 2 if t == "caramelo" else 1
                if self.nivel != 4:                  # en el nido la meta son serpientes, no dulces
                    self.comidos += 1
                self.vel_extra += 0.12
                self.snd.play("caramelo" if t == "caramelo" else "comer", self.rngs["frutas"])
                color = {"calabaza": (255, 150, 40), "caramelo": (240, 90, 160), "alma": (90, 200, 255)}[t]
                self.particulas_en(pos, color)
                if self.comidos >= self.meta:
                    self.completar_nivel()
                    return
                if t == "alma":
                    self.agregar_item("alma", self.vida_alma())
                else:
                    self.nueva_comida()
                self.extras_al_comer()
            elif t == "fruta":
                # Fruta carmesí: durante unos segundos puedes devorar serpientes
                self.poder = 7.0 - self.dif["extra"]          # Fácil 7 s, Normal 6 s, Pesadilla 5 s
                self.t_fruta = self.rngs["frutas"].exponencial(3.0) + 2
                self.sumar(40, pos)
                self.snd.play("poder")
                self.particulas_en(pos, (255, 60, 80), 26)
                self.aviso("¡Fruta carmesí! Devora las serpientes", pos, (255, 110, 120), 2.2)
            elif t == "veneno":
                self.veneno_t = 4.0
                self.snd.play("veneno")
                self.particulas_en(pos, (150, 255, 80), 20)
                self.aviso("¡Veneno! Controles invertidos", pos, (150, 255, 80), 2.0)
            elif t == "vela":
                self.luz = min(230.0, self.luz + 45)
                self.sumar(15, pos)
                self.snd.play("vela")
            elif t == "llave":
                self.llave = True
                self.sumar(100, pos)
                self.snd.play("llave")
                self.aviso("¡Llave calavera! La cripta te espera", pos, (200, 120, 255), 2.5)

    def devorar(self, en):
        """La serpiente del jugador (con el poder activo) se come a una víbora."""
        if en not in self.enemigos:
            return
        self.enemigos.remove(en)
        en.muerta = True
        self.comidos += 1
        self.crecer += 2
        self.sumar(150, en.cuerpo[0], (255, 110, 120))
        self.snd.play("devorar")
        for c in en.cuerpo[::2]:
            self.particulas_en(c, (170, 60, 200), 6)
        self.aviso(f"¡Serpiente devorada! {self.comidos}/{self.meta}", self.cabeza(), (255, 150, 200), 1.8)
        self.reapariciones.append(self.rngs["eventos"].real(2.0, 4.0))   # otra aparecerá luego
        if self.comidos >= self.meta:
            self.completar_nivel()

    def completar_nivel(self):
        self.sumar(200 * self.nivel)
        self.snd.play("nivel")
        siguiente = None
        if self.supervivencia:
            # Supervivencia: el generador elige otro nivel al azar, sin fin
            siguiente = self.rng.elegir([n for n in (1, 2, 3, 4, 5) if n != self.nivel])
            self.evento = ("completo", siguiente)
            return
        if self.nivel < 4:
            siguiente = self.nivel + 1
        elif self.nivel == 4:
            if self.llave:
                siguiente = 5
        if self.nivel == 5:
            self.premio_final = self.rng.entero(1, 5)      # bono sorteado: 100 a 500 puntos
            self.sumar(self.premio_final * 100)
        if siguiente:
            self.nivel_max = max(self.nivel_max, siguiente)
        self.evento = ("completo", siguiente)

    # ------------------------------------------------------------------ paso de la serpiente
    def paso(self):
        if self.cola:
            self.dir = self.cola.pop(0)
        dx, dy = self.dir
        hx, hy = self.cabeza()
        nueva = (hx + dx, hy + dy)
        if nueva in self.portales_set:                     # portal: destino aleatorio
            destino = self.rng.elegir([q for q in self.portales if q != nueva])
            self.particulas_en(nueva, (120, 255, 220), 16)
            nueva = (destino[0] + dx, destino[1] + dy)
            self.snd.play("portal")
        cuerpo = self.serp if self.crecer > 0 else self.serp[:-1]
        fantasma = self.nivel == 5 or self.invul > 0       # en la cripta, o mientras parpadea
        if not dentro(nueva) or nueva in self.obstaculos:
            if self.invul > 0:
                # Protegida: en vez de morir, gira hacia un lado libre
                for d in ((-dy, dx), (dy, -dx)):
                    c = (hx + d[0], hy + d[1])
                    if dentro(c) and c not in self.obstaculos and c not in self.portales_set:
                        self.dir, nueva = d, c
                        self.cola.clear()
                        break
                else:
                    return                                 # sin salida: espera quieta
            else:
                self.danio("¡Chocaste!" if dentro(nueva) else "¡Chocaste con el borde!")
                return
        if nueva in cuerpo and not fantasma:
            self.danio("¡Te mordiste la cola!")
            return
        if self.poder > 0:                                  # con la fruta carmesí: devoras
            for en in list(self.enemigos):
                if en.tipo == "vibora" and nueva in en.cuerpo:
                    self.devorar(en)
                    if self.evento:
                        return
        if self.invul <= 0:
            for en in self.enemigos:
                if nueva in en.cuerpo:
                    self.danio("¡Chocaste con una serpiente!")
                    return
            for m in self.manos:
                if m["fase"] == "activa" and m["pos"] == nueva:
                    self.danio("¡Una mano te atrapó!")
                    return
        self.serp.insert(0, nueva)
        if self.crecer > 0:
            self.crecer -= 1
        else:
            self.serp.pop()
        self.comer(nueva)

    # ------------------------------------------------------------------ ciclo
    def actualizar(self, dt):
        r = self.rng
        for m in self.mensajes:
            m[3] -= dt
            m[2] -= dt * 22
        self.mensajes = [m for m in self.mensajes if m[3] > 0]
        for p in self.particulas:
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[4] -= dt
        self.particulas = [p for p in self.particulas if p[4] > 0]
        self.shake = max(0.0, self.shake - dt)
        if self.terminada:
            return
        if self.t_muerte > 0:
            self.t_muerte -= dt
            if self.t_muerte <= 0:
                self.terminada = True
            return
        if self.evento:
            return

        self.invul = max(0.0, self.invul - dt)
        self.veneno_t = max(0.0, self.veneno_t - dt)

        self.acum += dt * self.velocidad()
        while self.acum >= 1 and not self.evento and self.t_muerte <= 0:
            self.acum -= 1
            self.paso()

        # Nivel 2: manos de esqueleto (tiempos exponenciales) y niebla que se mueve
        if self.nivel == 2:
            self.t_mano -= dt
            if self.t_mano <= 0:
                self.t_mano = self.rngs["enemigos"].exponencial(4.5 - 0.8 * self.dif["extra"]) + 0.5
                c = self.celda_libre(dist_min=3, rng=self.rngs["enemigos"])
                if c:
                    self.manos.append(dict(pos=c, fase="aviso", t=1.0))
            for m in self.manos:
                m["t"] -= dt
                if m["fase"] == "aviso" and m["t"] <= 0:
                    m["fase"], m["t"] = "activa", 2.4
                    self.snd.play("mano")
                    if m["pos"] == self.cabeza() and self.invul <= 0:
                        self.danio("¡Una mano te atrapó!")
            self.manos = [m for m in self.manos if not (m["fase"] == "activa" and m["t"] <= 0)]
            for nb in self.nieblas:
                nb[0] += nb[2] * dt
                if nb[0] > ANCHO + 40:
                    nb[0] = -200
                elif nb[0] < -220:
                    nb[0] = ANCHO + 20

        # Nivel 3: farol que se apaga y relámpagos (proceso de Poisson)
        if self.nivel == 3:
            self.luz = max(70.0, self.luz - 4.0 * dt)
            self.flash = max(0.0, self.flash - dt)
            self.t_rayo -= dt
            if self.t_rayo <= 0:
                self.flash = 0.45
                self.t_rayo = r.exponencial(6.0)
                self.snd.play("trueno")

        for v in self.voladores:
            v.actualizar(dt, self.rngs["enemigos"])
            cx, cy = self.cabeza()
            if self.invul <= 0 and self.t_muerte <= 0 and math.hypot(v.x - cx, v.y - cy) < 0.65:
                self.danio("¡Te atrapó un murciélago!" if v.tipo == "murcielago" else "¡Una calavera te golpeó!")

        for en in list(self.enemigos):
            en.actualizar(dt, self)
            if self.evento:
                return

        # Nivel 4: fruta carmesí y víboras que reaparecen
        if self.nivel == 4:
            if self.poder > 0:
                self.poder = max(0.0, self.poder - dt)
            elif not any(it["tipo"] == "fruta" for it in self.items):
                self.t_fruta -= dt
                if self.t_fruta <= 0:
                    self.agregar_item("fruta", 10.0)
                    self.aviso("Apareció una fruta carmesí", self.cabeza(), (255, 110, 120), 1.6)
                    self.t_fruta = self.rngs["frutas"].exponencial(3.0) + 2
            for i in range(len(self.reapariciones)):
                self.reapariciones[i] -= dt
            listas = [x for x in self.reapariciones if x <= 0]
            self.reapariciones = [x for x in self.reapariciones if x > 0]
            for _ in listas:
                self.agregar_serpiente("vibora", 5, self.vel_vibora, 0.4, lejos=True)

        for it in list(self.items):
            if it["vida"] is not None:
                it["vida"] -= dt
                if it["vida"] <= 0:
                    self.items.remove(it)
                    if it["tipo"] == "alma":               # el alma se esfuma y aparece en otro lado
                        self.agregar_item("alma", self.vida_alma())
                    elif it["tipo"] in ("calabaza", "caramelo"):   # el dulce se esfuma y sale otro
                        self.nueva_comida()

    # ------------------------------------------------------------------ dibujo
    def _capa(self, nombre, tam, color):
        """Superficie transparente reutilizable (más rápido, sobre todo en la web)."""
        if not hasattr(self, "_capas"):
            self._capas = {}
        capa = self._capas.get(nombre)
        if capa is None:
            capa = self._capas[nombre] = pygame.Surface(tam, pygame.SRCALPHA)
        capa.fill(color)
        return capa

    def dibujar(self, s, t, fuentes, record):
        s.blit(self.fondo, (0, HUD))
        n = self.nivel

        for m in self.manos:
            D.mano(s, m["pos"], m["fase"], 1 - m["t"] / 2.4 if m["fase"] == "activa" else 0, t)
        for c in self.portales:
            D.portal(s, c, t)
        for it in self.items:
            tipo = it["tipo"]
            if it["vida"] is not None and it["vida"] < 2.0 and int(t * 10) % 2:
                continue                                    # parpadea antes de desaparecer
            {"calabaza": D.calabaza, "caramelo": D.caramelo, "veneno": D.manzana_veneno,
             "vela": D.vela, "llave": D.llave_calavera, "fruta": D.fruta_carmesi}.get(
                tipo, lambda s_, c_, t_: D.alma(s_, c_, t_, it["vida"] / it["max"]))(s, it["pos"], t)

        for en in self.enemigos:
            if en.tipo == "zombi":
                D.serpiente(s, en.cuerpo, (110, 130, 105), (50, 62, 50), (255, 70, 60), t, puntadas=True)
            elif en.tipo == "sombra":
                D.serpiente(s, en.cuerpo, (28, 20, 30), (80, 12, 22), (255, 30, 30), t)
            elif en.tipo == "vibora":
                if self.poder > 0:                           # asustada: azul (parpadea al final)
                    blanca = self.poder < 2 and int(t * 8) % 2 == 0
                    col = (235, 235, 255) if blanca else (70, 110, 230)
                    D.serpiente(s, en.cuerpo, col, (30, 50, 120), (255, 255, 255), t, lengua=False)
                else:
                    D.serpiente(s, en.cuerpo, (130, 60, 170), (60, 20, 80), (255, 230, 60), t)
            else:
                col = (255, 120, 120) if en.furia > 0 else (215, 210, 195)
                D.serpiente(s, en.cuerpo, col, (120, 110, 100), (170, 60, 255), t, hueso=True, lengua=False)
                hx, hy = D.px(en.cuerpo[0])
                D.calavera(s, hx, hy - 2, 1.3, ojos=(140, 0, 220))

        # Serpiente del jugador
        visible = self.invul <= 0 or int(t * 12) % 2 == 0
        if visible and self.t_muerte <= 0:
            if self.veneno_t > 0:
                cuerpo, borde = (170, 90, 200), (70, 30, 90)
            else:
                cuerpo, borde = (110, 205, 70), (35, 85, 30)
            if self.poder > 0:                               # brilla con el poder de la fruta
                cuerpo, borde = (235, 60, 70), (120, 20, 30)
                D.halo(s, D.px(self.cabeza()), int(26 + 4 * math.sin(t * 10)), (255, 80, 90), 6, 26)
            if n == 5:
                capa = self._capa("fantasma", (ANCHO, ALTO), (0, 0, 0, 0))
                D.serpiente(capa, self.serp, (150, 240, 230), (60, 140, 160), (255, 255, 255), t)
                capa.set_alpha(175)
                s.blit(capa, (0, 0))
            else:
                D.serpiente(s, self.serp, cuerpo, borde, (255, 230, 80), t)

        for v in self.voladores:
            x, y = D.px((v.x, v.y))
            if v.tipo == "murcielago":
                D.murcielago(s, x, y, t, 1.2)
            else:
                D.halo(s, (x, y), 18, (80, 200, 255), 4, 20)
                D.calavera(s, x, y, 0.95, col=(200, 220, 230), ojos=(80, 200, 255))

        if n == 2:
            for nb in self.nieblas:
                s.blit(nb[3], (int(nb[0]), int(nb[1])))

        if n == 3:                                           # oscuridad
            osc = 238 if self.flash <= 0 else int(238 * (1 - min(1.0, self.flash / 0.25)) ** 2)
            osc = (osc // 17) * 17
            if osc > 0:
                capa = self._capa("oscuridad", (ANCHO, FILAS * CELDA), (0, 0, 0, osc))
                luces = [(self.cabeza(), int(self.luz) // 10 * 10)]
                luces += [(it["pos"], 60) for it in self.items if it["tipo"] in ("vela", "llave")]
                for c, radio in luces:
                    x, y = D.px(c)
                    capa.blit(D.agujero_luz(radio, osc), (x - radio, y - HUD - radio),
                              special_flags=pygame.BLEND_RGBA_MIN)
                s.blit(capa, (0, HUD))
                for en in self.enemigos:
                    D.ojos_rojos(s, en.cuerpo[0], t)
            if self.flash > 0.3:
                destello = self._capa("destello", (ANCHO, FILAS * CELDA),
                                      (220, 220, 255, int(120 * (self.flash - 0.3) / 0.15)))
                s.blit(destello, (0, HUD))

        for p in self.particulas:
            pygame.draw.circle(s, p[5], (int(p[0]), int(p[1])), max(1, int(p[4] * 5)))
        for txt, x, y, vida, col in self.mensajes:
            D.texto(s, txt, fuentes["p"], col, centro=(int(x), int(y)), sombra=True)

        self.dibujar_hud(s, t, fuentes, record)

    def dibujar_hud(self, s, t, f, record):
        cfg = NIVELES[self.nivel]
        pygame.draw.rect(s, (12, 8, 16), (0, 0, ANCHO, HUD))
        pygame.draw.line(s, cfg["color"], (0, HUD - 1), (ANCHO, HUD - 1), 2)
        D.texto(s, f"PUNTOS {self.puntos}", f["m"], TEXTO, pos=(12, 10))
        D.texto(s, f"Récord {max(record, self.puntos)}", f["p"], TENUE, pos=(12, 38))
        titulo = ("NIVEL SECRETO · " if self.nivel == 5 else f"NIVEL {self.nivel} · ") + cfg["nombre"]
        D.texto(s, titulo, f["t"], cfg["color"], centro=(ANCHO // 2, 21))
        sub = f"Supervivencia · ronda {self.ronda}" if self.supervivencia else cfg["sub"]
        D.texto(s, sub, f["p"], TENUE, centro=(ANCHO // 2, 47))
        for i in range(min(self.vidas, 7)):
            D.calavera(s, ANCHO - 20 - i * 22, 20, 0.8)

        y0 = HUD + FILAS * CELDA
        pygame.draw.rect(s, (12, 8, 16), (0, y0, ANCHO, PIE))
        pygame.draw.line(s, cfg["color"], (0, y0), (ANCHO, y0), 2)
        D.texto(s, "Avance", f["p"], TENUE, pos=(12, y0 + 15))
        barra = pygame.Rect(76, y0 + 15, 220, 16)
        pygame.draw.rect(s, (50, 40, 60), barra, border_radius=8)
        lleno = barra.copy()
        lleno.width = int(barra.width * min(1.0, self.comidos / self.meta))
        pygame.draw.rect(s, cfg["color"], lleno, border_radius=8)
        D.texto(s, f"{self.comidos}/{self.meta}", f["p"], TEXTO, pos=(barra.right + 8, y0 + 15))
        for i, nv in enumerate((1, 2, 3, 4, 5)):              # mapa de etapas
            x = 370 + i * 24
            hecho = nv < self.nivel or (nv == self.nivel and self.comidos >= self.meta)
            actual = nv == self.nivel
            col = NIVELES[nv]["color"] if (hecho or actual) else (70, 60, 80)
            if nv == 5 and self.nivel_max < 5 and not self.llave:
                D.texto(s, "?", f["p"], (90, 80, 100), centro=(x, y0 + 23))
            else:
                pygame.draw.circle(s, col, (x, y0 + 23), 8 if actual else 6, 0 if hecho or actual else 2)
        estado = []
        if self.poder > 0:
            estado.append((f"¡Poder! {self.poder:.1f}s", (255, 110, 120)))
        if self.veneno_t > 0:
            estado.append((f"Invertido {self.veneno_t:.1f}s", (150, 255, 80)))
        if self.llave:
            estado.append(("Llave calavera: sí", (200, 120, 255)))
        if not estado:
            estado.append((self.nombre_gen, TENUE))
        D.texto(s, "   ".join(e[0] for e in estado), f["p"], estado[0][1], der=(ANCHO - 12, y0 + 15))
