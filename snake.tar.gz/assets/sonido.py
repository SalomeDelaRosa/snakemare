# -*- coding: utf-8 -*-
"""
Música y efectos de sonido sintetizados con matemáticas (no hay archivos de audio).
La MÚSICA de cada nivel se compone al azar con el generador elegido por el jugador:
una caminata aleatoria sobre una escala de terror + una línea de bajo aleatoria.
"""
import math
import os
import sys
from array import array

import pygame

try:                      # en la versión web (pygbag) el módulo de sonido se importa aparte
    import pygame.mixer   # noqa: F401
except Exception:
    pass

# Escalas "de miedo" por nivel: (notas en Hz, duración de corchea, forma de onda, corcheas por compás)
ESCALAS = {
    "menu": ([220.00, 261.63, 293.66, 329.63, 392.00], 0.30, "organo", 8),        # La menor pentatónica
    1: ([220.00, 261.63, 293.66, 329.63, 392.00], 0.22, "triangular", 8),          # cementerio
    2: ([293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25], 0.20, "triangular", 6),  # Re dórico (marinero)
    3: ([220.00, 246.94, 261.63, 293.66, 329.63, 349.23, 415.30], 0.27, "organo", 8),     # La menor armónica
    4: ([164.81, 174.61, 196.00, 220.00, 246.94, 261.63, 293.66], 0.19, "triangular", 8),  # Mi frigio (nido)
    5: ([261.63, 293.66, 329.63, 369.99, 415.30, 466.16], 0.21, "seno", 8),               # tonos enteros (irreal)
}


class Sonidos:
    def __init__(self, rng_ruido, crear=True):
        self.activo = False
        self.musica_on = True
        self.efectos_on = True
        self.efectos = {}
        self.musica_actual = None
        self.archivo_actual = None
        self.cache_musica = {}
        if not crear:                                     # sonido "apagado" mientras carga la web
            return
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init()
            info = pygame.mixer.get_init()
            if not info:
                return
            self.fr, _, self.canales = info
            self.activo = True
            self._crear_efectos(rng_ruido)
        except Exception:
            # Si el navegador o el computador no permiten sonido, el juego sigue en silencio
            self.activo = False
            self.efectos = {}

    # ------------------------------------------------------------------ síntesis
    @staticmethod
    def _onda(forma, fase):
        if forma == "seno":
            return math.sin(2 * math.pi * fase)
        if forma == "cuadrada":
            return 1.0 if fase < 0.5 else -1.0
        if forma == "organo":
            return 0.7 * math.sin(2 * math.pi * fase) + 0.3 * math.sin(4 * math.pi * fase)
        return 4 * abs(fase - 0.5) - 1                      # triangular

    def _a_sonido(self, muestras):
        if self.canales == 2:
            estereo = array("h")
            for s in muestras:
                estereo.append(s)
                estereo.append(s)
            muestras = estereo
        return pygame.mixer.Sound(buffer=muestras.tobytes())

    def _tono(self, notas, vol, forma="triangular", vibrato=0.0):
        muestras = array("h")
        for f, dur in notas:
            n = int(dur * self.fr)
            ataque, caida = max(1, int(0.004 * self.fr)), max(1, int(0.03 * self.fr))
            fase = 0.0
            for i in range(n):
                env = min(1.0, i / ataque, (n - i) / caida)
                fi = f * (1 + vibrato * math.sin(2 * math.pi * 7 * i / self.fr))
                fase = (fase + fi / self.fr) % 1.0
                muestras.append(int(self._onda(forma, fase) * env * vol * 32767))
        return self._a_sonido(muestras)

    def _ruido(self, rng, dur, vol, suavizado=0.15, grave=0.0):
        """Ruido blanco hecho con el generador pseudoaleatorio + filtro pasa-bajos."""
        n = int(dur * self.fr)
        muestras = array("h")
        y = 0.0
        for i in range(n):
            x = rng.uniforme() * 2 - 1
            y += suavizado * (x - y)
            env = (1 - i / n) ** 2
            tono = math.sin(2 * math.pi * grave * i / self.fr) * 0.5 if grave else 0
            muestras.append(int(max(-1, min(1, (y + tono) * env * vol)) * 32767))
        return self._a_sonido(muestras)

    def _crear_efectos(self, rng):
        self.efectos["comer"] = [self._tono([(f * 2, 0.04), (f * 3, 0.05)], 0.16, "cuadrada")
                                 for f in (220, 261.63, 293.66, 329.63)]
        self.efectos["caramelo"] = self._tono([(523, 0.04), (659, 0.04), (784, 0.04), (1046, 0.08)], 0.15, "cuadrada")
        self.efectos["veneno"] = self._tono([(400, 0.12), (300, 0.12), (220, 0.25)], 0.25, "triangular", vibrato=0.05)
        self.efectos["moneda"] = self._tono([(988, 0.07), (1319, 0.22)], 0.18, "cuadrada")
        self.efectos["vela"] = self._tono([(440, 0.06), (660, 0.06), (880, 0.14)], 0.22, "seno")
        self.efectos["llave"] = self._tono([(440, 0.1), (523, 0.1), (659, 0.1), (831, 0.3)], 0.22, "organo")
        self.efectos["golpe"] = self._ruido(rng, 0.45, 0.9, 0.25, grave=70)
        self.efectos["corte"] = self._tono([(900, 0.04), (500, 0.04), (250, 0.08)], 0.2, "cuadrada")
        self.efectos["portal"] = self._tono([(300 + i * 70, 0.025) for i in range(16)], 0.2, "seno")
        self.efectos["trueno"] = self._ruido(rng, 1.3, 1.0, 0.06, grave=45)
        self.efectos["mano"] = self._ruido(rng, 0.35, 0.6, 0.08, grave=90)
        self.efectos["nivel"] = self._tono([(f, 0.11) for f in (220, 261.63, 329.63, 440, 523.25, 659.25)], 0.2, "organo")
        self.efectos["fin"] = self._tono([(330, 0.25), (311, 0.25), (294, 0.25), (220, 0.7)], 0.22, "organo", vibrato=0.01)
        self.efectos["victoria"] = self._tono([(f, 0.12) for f in (261.63, 329.63, 392, 523.25, 392, 523.25)] + [(659.25, 0.5)], 0.2, "organo")
        self.efectos["poder"] = self._tono([(220 + i * 55, 0.035) for i in range(14)] + [(990, 0.18)], 0.2, "cuadrada")
        self.efectos["devorar"] = self._ruido(rng, 0.3, 0.8, 0.3, grave=110)
        self.efectos["vida"] = self._tono([(f * 2, 0.06) for f in (261.63, 329.63, 392, 523.25)], 0.18, "triangular")
        self.efectos["menu"] = self._tono([(660, 0.03)], 0.12, "cuadrada")
        self.efectos["risa"] = self._tono([(f, 0.09) for f in (520, 470, 520, 470, 520, 400)], 0.18, "triangular", vibrato=0.04)

    # ------------------------------------------------------------------ música
    def componer(self, clave, rng):
        """Compone una pieza aleatoria con el generador recibido."""
        if not self.activo:
            return None
        try:
            return self._componer(clave, rng)
        except Exception:
            return None

    def _componer(self, clave, rng):
        escala, corchea, forma, por_compas = ESCALAS[clave]
        compases = 4 if sys.platform == "emscripten" else 8   # en la web: piezas más cortas
        notas_ext = [f for f in escala] + [f * 2 for f in escala]
        raices = [escala[0] / 2, escala[3] / 2, escala[4 if len(escala) > 4 else 2] / 2, escala[1] / 2]
        progresion = [raices[0]] + [rng.elegir(raices) for _ in range(compases - 1)]
        grado = rng.entero(2, len(escala) + 1)
        notas = []
        for c in range(compases):
            k = 0
            while k < por_compas:
                dur = min(rng.elegir_ponderado([1, 2, 3], [0.6, 0.3, 0.1]), por_compas - k)
                grado = max(0, min(len(notas_ext) - 1, grado + rng.elegir([-2, -1, -1, 0, 1, 1, 2])))
                f = 0 if rng.probabilidad(0.15) else notas_ext[grado]
                notas.append((c, f, dur))
                k += dur
        muestras = array("h")
        nc = int(corchea * self.fr)
        t = 0
        fase_m = 0.0
        for c, f, dur in notas:
            n = nc * dur
            b = progresion[c]
            for i in range(n):
                env = min(1.0, i / 120, (n - i) / 600)
                if f:
                    fase_m = (fase_m + f / self.fr) % 1.0
                    mel = self._onda(forma, fase_m) * env
                else:
                    mel = 0.0
                bajo = math.sin(2 * math.pi * b * t / self.fr)
                muestras.append(int((0.13 * mel + 0.11 * bajo) * 32767))
                t += 1
        return self._a_sonido(muestras)

    # ------------------------------------------------------------------ canciones propias
    CARPETA_MUSICA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "musica")
    EXTENSIONES = (".mp3", ".ogg", ".wav")

    def buscar_cancion(self, clave, rng):
        """Busca en la carpeta 'musica':
        1) una canción con el nombre exacto: menu.mp3, nivel1.mp3 ... nivel5.mp3
        2) si no hay, cualquier otra canción de la carpeta, elegida con el generador."""
        if not self.activo or not os.path.isdir(self.CARPETA_MUSICA):
            return None
        archivos = sorted(f for f in os.listdir(self.CARPETA_MUSICA) if f.lower().endswith(self.EXTENSIONES))
        nombre = "menu" if clave == "menu" else f"nivel{clave}"
        for f in archivos:
            if os.path.splitext(f)[0].lower() == nombre:
                return os.path.join(self.CARPETA_MUSICA, f)
        reservados = {"menu", "nivel1", "nivel2", "nivel3", "nivel4", "nivel5"}
        libres = [f for f in archivos if os.path.splitext(f)[0].lower() not in reservados]
        if libres:
            return os.path.join(self.CARPETA_MUSICA, rng.elegir(libres))
        return None

    def tocar_archivo(self, ruta):
        """Toca una canción (mp3, ogg o wav) en bucle. Devuelve False si no se pudo abrir."""
        if not self.activo:
            return False
        try:
            self.detener_musica()
            pygame.mixer.music.load(ruta)
            pygame.mixer.music.set_volume(0.5)
            self.musica_actual = None
            self.archivo_actual = ruta
            if self.musica_on:
                pygame.mixer.music.play(loops=-1)
            return True
        except pygame.error:
            self.archivo_actual = None
            return False

    def tocar_musica(self, sonido):
        if not self.activo:
            return
        self.archivo_actual = None
        try:
            pygame.mixer.music.stop()
        except Exception:
            pass
        if self.musica_actual is not None:
            self.musica_actual.stop()
        self.musica_actual = sonido
        if sonido is not None and self.musica_on:
            sonido.set_volume(0.55)
            sonido.play(loops=-1)

    def detener_musica(self):
        if not self.activo:
            return
        if self.musica_actual is not None:
            self.musica_actual.stop()
        try:
            pygame.mixer.music.stop()
        except Exception:
            pass

    def modo(self):
        if self.musica_on and self.efectos_on:
            return "Música y efectos"
        if self.efectos_on:
            return "Solo efectos"
        return "Silencio"

    def ciclar_modo(self):
        """Música y efectos -> Solo efectos -> Silencio -> ..."""
        if self.musica_on:
            self.musica_on = False
        elif self.efectos_on:
            self.efectos_on = False
        else:
            self.musica_on = self.efectos_on = True
        if self.activo and self.musica_actual is not None:
            self.musica_actual.stop()
            if self.musica_on:
                self.musica_actual.play(loops=-1)
        if self.activo and getattr(self, "archivo_actual", None):
            try:
                if self.musica_on:
                    pygame.mixer.music.play(loops=-1)
                else:
                    pygame.mixer.music.stop()
            except Exception:
                pass

    def play(self, nombre, rng=None):
        if not (self.activo and self.efectos_on):
            return
        s = self.efectos.get(nombre)
        if isinstance(s, list):
            s = rng.elegir(s) if rng else s[0]
        if s:
            s.play()
