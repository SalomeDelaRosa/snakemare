# -*- coding: utf-8 -*-
"""Todo lo que se dibuja: personajes, objetos y escenarios (sin imágenes externas)."""
import math

import pygame

from config import CELDA, COLS, FILAS, HUD, ANCHO

TABLERO_ALTO = FILAS * CELDA


def px(c):
    """Celda (x, y) -> centro en píxeles de la pantalla."""
    return int(c[0] * CELDA + CELDA // 2), int(HUD + c[1] * CELDA + CELDA // 2)


def texto(s, t, fuente, color, pos=None, centro=None, der=None, sombra=False):
    if sombra:
        img = fuente.render(t, True, (0, 0, 0))
        r = img.get_rect()
        if centro: r.center = (centro[0] + 2, centro[1] + 2)
        elif der: r.topright = (der[0] + 2, der[1] + 2)
        else: r.topleft = (pos[0] + 2, pos[1] + 2)
        s.blit(img, r)
    img = fuente.render(t, True, color)
    r = img.get_rect()
    if centro: r.center = centro
    elif der: r.topright = der
    else: r.topleft = pos
    s.blit(img, r)
    return r


_cache_halos = {}


def halo(s, centro, radio, color, capas=6, alfa=16):
    """Brillo circular. Se guarda en caché para no recrearlo en cada cuadro."""
    clave = (radio, tuple(color), capas, alfa)
    capa = _cache_halos.get(clave)
    if capa is None:
        capa = pygame.Surface((radio * 2, radio * 2), pygame.SRCALPHA)
        for k in range(capas):
            r = int(radio * (1 - k / capas))
            pygame.draw.circle(capa, (*color, alfa), (radio, radio), max(1, r))
        if len(_cache_halos) > 400:
            _cache_halos.clear()
        _cache_halos[clave] = capa
    s.blit(capa, (centro[0] - radio, centro[1] - radio))


def degradado(s, arriba, abajo, rect):
    x, y, w, h = rect
    for i in range(h):
        k = i / max(1, h - 1)
        col = [int(arriba[j] + (abajo[j] - arriba[j]) * k) for j in range(3)]
        pygame.draw.line(s, col, (x, y + i), (x + w, y + i))


# ======================================================================
# SERPIENTES
# ======================================================================
def serpiente(s, celdas, cuerpo, borde, ojos, t=0.0, puntadas=False, lengua=True, hueso=False):
    if not celdas:
        return
    n = len(celdas)
    for i in range(n - 1, -1, -1):
        cx, cy = px(celdas[i])
        r = int(CELDA * 0.47 - (i / max(1, n)) * 4)
        if i < n - 1:
            a, b = celdas[i], celdas[i + 1]
            if abs(a[0] - b[0]) + abs(a[1] - b[1]) == 1:        # no unir si pasó por un portal
                nx, ny = px(b)
                pygame.draw.line(s, borde, (cx, cy), (nx, ny), 2 * r + 2)
                pygame.draw.line(s, cuerpo, (cx, cy), (nx, ny), 2 * r - 2)
        if hueso:
            pygame.draw.ellipse(s, cuerpo, (cx - r, cy - r + 3, 2 * r, 2 * r - 6))
            pygame.draw.line(s, borde, (cx, cy - r), (cx, cy + r), 3)
        else:
            pygame.draw.circle(s, borde, (cx, cy), r + 1)
            pygame.draw.circle(s, cuerpo, (cx, cy), r - 1)
            if i % 2 == 0 and i > 0:                              # escamas
                pygame.draw.circle(s, borde, (cx, cy), max(2, r // 3))
        if puntadas and i % 3 == 1:
            pygame.draw.line(s, (40, 25, 25), (cx - 5, cy - 5), (cx + 5, cy + 5), 2)
            pygame.draw.line(s, (40, 25, 25), (cx - 5, cy + 5), (cx + 5, cy - 5), 2)
    hx, hy = px(celdas[0])
    if n > 1 and abs(celdas[0][0] - celdas[1][0]) + abs(celdas[0][1] - celdas[1][1]) == 1:
        ax, ay = celdas[0][0] - celdas[1][0], celdas[0][1] - celdas[1][1]
    else:
        ax, ay = 1, 0
    pxp, pyp = -ay, ax
    pygame.draw.circle(s, borde, (hx + ax * 3, hy + ay * 3), 12)
    pygame.draw.circle(s, cuerpo, (hx + ax * 3, hy + ay * 3), 10)
    for lado in (-1, 1):
        ex, ey = hx + ax * 5 + pxp * 5 * lado, hy + ay * 5 + pyp * 5 * lado
        pygame.draw.circle(s, ojos, (ex, ey), 4)
        pygame.draw.circle(s, (0, 0, 0), (ex + ax, ey + ay), 2)
    if lengua and int(t * 4) % 3 == 0:
        lx, ly = hx + ax * 18, hy + ay * 18
        roja = (230, 40, 60)
        pygame.draw.line(s, roja, (hx + ax * 12, hy + ay * 12), (lx, ly), 2)
        pygame.draw.line(s, roja, (lx, ly), (lx + ax * 4 + pxp * 3, ly + ay * 4 + pyp * 3), 2)
        pygame.draw.line(s, roja, (lx, ly), (lx + ax * 4 - pxp * 3, ly + ay * 4 - pyp * 3), 2)


def ojos_rojos(s, c, t):
    x, y = px(c)
    brillo = 180 + int(60 * math.sin(t * 5))
    for lado in (-5, 5):
        halo(s, (x + lado, y), 10, (255, 40, 40), 4, 30)
        pygame.draw.circle(s, (brillo, 30, 30), (x + lado, y), 3)


# ======================================================================
# OBJETOS
# ======================================================================
def calabaza(s, c, t=0.0):
    x, y = px(c)
    y += int(math.sin(t * 3 + c[0]) * 1.5)
    pygame.draw.rect(s, (60, 110, 40), (x - 2, y - 13, 4, 6))
    for dx in (-5, 5, 0):
        pygame.draw.ellipse(s, (240, 120, 20) if dx else (255, 145, 30), (x + dx - 7, y - 9, 14, 19))
    pygame.draw.polygon(s, (40, 15, 0), [(x - 6, y - 3), (x - 2, y - 3), (x - 4, y - 6)])
    pygame.draw.polygon(s, (40, 15, 0), [(x + 6, y - 3), (x + 2, y - 3), (x + 4, y - 6)])
    pygame.draw.polygon(s, (255, 220, 60), [(x - 6, y + 2), (x + 6, y + 2), (x + 3, y + 6), (x - 3, y + 6)])


def caramelo(s, c, t=0.0):
    x, y = px(c)
    ang = t * 2
    pygame.draw.polygon(s, (240, 90, 160), [(x - 7, y), (x - 13, y - 6), (x - 13, y + 6)])
    pygame.draw.polygon(s, (240, 90, 160), [(x + 7, y), (x + 13, y - 6), (x + 13, y + 6)])
    pygame.draw.circle(s, (250, 250, 250), (x, y), 8)
    for k in range(3):
        a = ang + k * 2.09
        pygame.draw.line(s, (220, 40, 120), (x, y), (x + 7 * math.cos(a), y + 7 * math.sin(a)), 3)


def manzana_veneno(s, c, t=0.0):
    x, y = px(c)
    halo(s, (x, y), 22, (150, 255, 80), 6, 14 + int(8 * math.sin(t * 6)))
    pygame.draw.circle(s, (110, 30, 140), (x, y + 1), 9)
    pygame.draw.circle(s, (160, 60, 190), (x - 3, y - 2), 3)
    pygame.draw.line(s, (60, 40, 20), (x, y - 8), (x + 2, y - 13), 2)
    pygame.draw.ellipse(s, (130, 230, 60), (x + 2, y - 14, 7, 4))
    gota = int((t * 20) % 8)
    pygame.draw.circle(s, (150, 255, 80), (x - 4, y + 9 + gota // 2), 2)
    pygame.draw.circle(s, (230, 230, 230), (x, y + 1), 3)
    pygame.draw.rect(s, (230, 230, 230), (x - 2, y + 3, 4, 2))


def moneda(s, c, t=0.0):
    x, y = px(c)
    ancho = max(2, int(9 * abs(math.cos(t * 4))))
    halo(s, (x, y), 18, (255, 200, 40), 4, 18)
    pygame.draw.ellipse(s, (255, 190, 0), (x - ancho, y - 9, 2 * ancho, 18))
    pygame.draw.ellipse(s, (170, 110, 0), (x - ancho, y - 9, 2 * ancho, 18), 2)


def vela(s, c, t=0.0):
    x, y = px(c)
    pygame.draw.rect(s, (235, 225, 200), (x - 3, y - 3, 6, 12))
    pygame.draw.ellipse(s, (235, 225, 200), (x - 5, y + 7, 10, 4))
    llama = 1 + 0.15 * math.sin(t * 12 + c[0])
    halo(s, (x, y - 8), 22, (255, 190, 80), 6, 22)
    pygame.draw.ellipse(s, (255, 200, 60), (x - 3, y - 13 * llama, 6, 10 * llama))
    pygame.draw.ellipse(s, (255, 250, 200), (x - 1, y - 9, 3, 5))


def llave_calavera(s, c, t=0.0):
    x, y = px(c)
    y += int(math.sin(t * 4) * 2)
    halo(s, (x, y), 24, (200, 120, 255), 6, 20)
    pygame.draw.rect(s, (230, 200, 120), (x - 1, y - 2, 3, 13))
    pygame.draw.rect(s, (230, 200, 120), (x + 2, y + 6, 5, 3))
    pygame.draw.rect(s, (230, 200, 120), (x + 2, y + 1, 4, 3))
    calavera(s, x, y - 6, 0.6, col=(240, 230, 210), ojos=(120, 40, 160))


def alma(s, c, t=0.0, vida=1.0):
    x, y = px(c)
    y += int(math.sin(t * 5 + c[1]) * 2)
    col = (90, 200, 255)
    halo(s, (x, y), 24, col, 6, int(10 + 12 * vida))
    pygame.draw.polygon(s, col, [(x, y - 12), (x + 7, y + 2), (x + 4, y + 8), (x - 4, y + 8), (x - 7, y + 2)])
    pygame.draw.circle(s, col, (x, y + 3), 7)
    pygame.draw.circle(s, (230, 250, 255), (x, y + 4), 3)


def calavera(s, x, y, e=1.0, col=(230, 225, 210), ojos=(0, 0, 0)):
    pygame.draw.circle(s, col, (int(x), int(y)), int(9 * e))
    pygame.draw.rect(s, col, (x - 5 * e, y + 4 * e, 10 * e, 7 * e), border_radius=2)
    pygame.draw.circle(s, ojos, (int(x - 4 * e), int(y)), max(1, int(3 * e)))
    pygame.draw.circle(s, ojos, (int(x + 4 * e), int(y)), max(1, int(3 * e)))
    pygame.draw.polygon(s, ojos, [(x, y + 3 * e), (x - 2 * e, y + 6 * e), (x + 2 * e, y + 6 * e)])


def mano(s, c, fase, progreso, t):
    """fase 'aviso': grietas que tiemblan.  fase 'activa': mano de esqueleto."""
    x, y = px(c)
    if fase == "aviso":
        temblor = int(math.sin(t * 50) * 2)
        col = (255, 80, 60) if int(t * 8) % 2 else (120, 30, 30)
        for dx, dy in ((-9, -6), (8, -7), (-7, 8), (9, 7), (0, -10)):
            pygame.draw.line(s, col, (x + temblor, y), (x + dx + temblor, y + dy), 2)
        return
    sube = min(1.0, progreso * 4)
    hueso = (225, 220, 200)
    pygame.draw.ellipse(s, (25, 15, 10), (x - 11, y + 3, 22, 9))
    base = y + 6 - int(10 * sube)
    pygame.draw.rect(s, hueso, (x - 2, base, 5, 9))
    pygame.draw.ellipse(s, hueso, (x - 6, base - 4, 12, 8))
    for i, dx in enumerate((-5, -2, 1, 4)):
        alto = (7, 10, 9, 6)[i]
        doblez = int(math.sin(t * 6 + i) * 2)
        pygame.draw.line(s, hueso, (x + dx, base - 2), (x + dx - 1 + doblez, base - 2 - alto), 2)
    pygame.draw.line(s, hueso, (x + 5, base), (x + 9, base - 4), 2)


def murcielago(s, x, y, t, e=1.0, col=(105, 75, 140)):
    aleteo = math.sin(t * 18) * 4 * e
    halo(s, (int(x), int(y)), int(16 * e), (200, 150, 255), 4, 14)
    pygame.draw.ellipse(s, col, (x - 4 * e, y - 3 * e, 8 * e, 7 * e))
    for lado in (-1, 1):
        pts = [(x, y), (x + lado * 6 * e, y - 6 * e - aleteo), (x + lado * 14 * e, y - 3 * e - aleteo),
               (x + lado * 11 * e, y + 1 * e), (x + lado * 7 * e, y - 1 * e), (x + lado * 4 * e, y + 3 * e)]
        pygame.draw.polygon(s, col, pts)
    pygame.draw.circle(s, (255, 60, 60), (int(x - 2 * e), int(y - 1 * e)), max(1, int(e)))
    pygame.draw.circle(s, (255, 60, 60), (int(x + 2 * e), int(y - 1 * e)), max(1, int(e)))


def portal(s, c, t, col1=(120, 255, 220), col2=(60, 140, 160)):
    x, y = px(c)
    halo(s, (x, y), 26, col1, 5, 18)
    for k, r in enumerate(range(16, 2, -3)):
        g = (t * 3 + k * 0.6)
        rr = r + math.sin(g) * 1.5
        pygame.draw.ellipse(s, col1 if k % 2 else col2, (x - rr * 0.75, y - rr, rr * 1.5, rr * 2), 2)


# ======================================================================
# ESCENARIOS (se dibujan una sola vez por nivel)
# ======================================================================
def _lapida(s, x, y, grieta):
    w, h = 18, 20
    rect = (x - w // 2, y - h // 2 + 2, w, h)
    pygame.draw.rect(s, (95, 95, 110), rect, border_top_left_radius=9, border_top_right_radius=9)
    pygame.draw.rect(s, (55, 55, 70), rect, 2, border_top_left_radius=9, border_top_right_radius=9)
    pygame.draw.line(s, (50, 50, 60), (x, y - 5), (x, y + 6), 2)
    pygame.draw.line(s, (50, 50, 60), (x - 4, y - 1), (x + 4, y - 1), 2)
    if grieta:
        pygame.draw.line(s, (50, 50, 60), (x + 3, y - 7), (x + 7, y + 1), 1)


def _barril(s, x, y):
    pygame.draw.ellipse(s, (95, 60, 30), (x - 10, y - 11, 20, 23))
    pygame.draw.ellipse(s, (60, 38, 20), (x - 10, y - 11, 20, 23), 2)
    pygame.draw.line(s, (40, 40, 45), (x - 10, y - 4), (x + 10, y - 4), 2)
    pygame.draw.line(s, (40, 40, 45), (x - 10, y + 5), (x + 10, y + 5), 2)


def construir_fondo(nivel, obstaculos, rng):
    """Dibuja el escenario del nivel en una superficie del tamaño del tablero."""
    s = pygame.Surface((ANCHO, TABLERO_ALTO))
    if nivel == 1:                                       # cementerio
        degradado(s, (38, 20, 58), (14, 24, 18), (0, 0, ANCHO, TABLERO_ALTO))
        for y in range(FILAS):
            for x in range(COLS):
                if (x + y) % 2 == 0:
                    capa = pygame.Surface((CELDA, CELDA), pygame.SRCALPHA)
                    capa.fill((40, 80, 50, 40))
                    s.blit(capa, (x * CELDA, y * CELDA))
        pygame.draw.circle(s, (245, 240, 205), (ANCHO - 70, 50), 34)
        pygame.draw.circle(s, (222, 218, 182), (ANCHO - 80, 42), 6)
        pygame.draw.circle(s, (222, 218, 182), (ANCHO - 60, 62), 4)
        for _ in range(90):
            x, y = rng.entero(0, ANCHO), rng.entero(0, TABLERO_ALTO)
            pygame.draw.line(s, (45, 80, 45), (x, y), (x + rng.entero(-3, 3), y - rng.entero(3, 7)), 1)
        for (cx, cy) in obstaculos:
            x, y = cx * CELDA + CELDA // 2, cy * CELDA + CELDA // 2
            _lapida(s, x, y, rng.probabilidad(0.4))
    elif nivel == 2:                                     # barco
        for y in range(FILAS):
            for x in range(COLS):
                base = 72 + ((y * 7 + x // 4 * 13) % 3) * 8
                pygame.draw.rect(s, (base, int(base * 0.62), int(base * 0.38)), (x * CELDA, y * CELDA, CELDA, CELDA))
            pygame.draw.line(s, (35, 22, 14), (0, y * CELDA), (ANCHO, y * CELDA), 1)
            for x in range((y * 3) % 4, COLS, 4):
                pygame.draw.line(s, (35, 22, 14), (x * CELDA, y * CELDA), (x * CELDA, (y + 1) * CELDA), 1)
        for _ in range(25):                               # clavos
            x, y = rng.entero(0, ANCHO), rng.entero(0, TABLERO_ALTO)
            pygame.draw.circle(s, (40, 30, 25), (x, y), 1)
        for (cx, cy) in obstaculos:
            _barril(s, cx * CELDA + CELDA // 2, cy * CELDA + CELDA // 2)
    elif nivel == 3:                                     # mansión
        for y in range(FILAS):
            for x in range(COLS):
                col = (70, 18, 26) if (x + y) % 2 == 0 else (30, 12, 18)
                pygame.draw.rect(s, col, (x * CELDA, y * CELDA, CELDA, CELDA))
        for (cx, cy) in obstaculos:
            r = pygame.Rect(cx * CELDA, cy * CELDA, CELDA, CELDA)
            pygame.draw.rect(s, (62, 56, 70), r)
            pygame.draw.rect(s, (38, 32, 46), r, 2)
            pygame.draw.line(s, (38, 32, 46), (r.x, r.centery), (r.right, r.centery), 1)
        for (x0, y0) in ((0, 0), (ANCHO, 0), (0, TABLERO_ALTO), (ANCHO, TABLERO_ALTO)):   # telarañas
            for k in range(1, 5):
                rr = k * 16
                pygame.draw.circle(s, (110, 110, 120), (x0, y0), rr, 1)
            for ang in range(0, 360, 30):
                a = math.radians(ang)
                pygame.draw.line(s, (110, 110, 120), (x0, y0), (x0 + 70 * math.cos(a), y0 + 70 * math.sin(a)), 1)
    elif nivel == 4:                                     # nido de serpientes
        degradado(s, (22, 34, 20), (36, 22, 30), (0, 0, ANCHO, TABLERO_ALTO))
        for _ in range(140):                              # musgo
            x, y = rng.entero(0, ANCHO), rng.entero(0, TABLERO_ALTO)
            pygame.draw.circle(s, (40, 62, 34), (x, y), rng.entero(2, 6))
        for _ in range(14):                               # raíces
            x, y = rng.entero(0, ANCHO), rng.entero(0, TABLERO_ALTO)
            pts = [(x, y)]
            for _ in range(5):
                x += rng.entero(-30, 30)
                y += rng.entero(10, 30)
                pts.append((x, y))
            pygame.draw.lines(s, (62, 40, 28), False, pts, 3)
        for (cx, cy) in obstaculos:                       # huevos de serpiente
            x, y = cx * CELDA + CELDA // 2, cy * CELDA + CELDA // 2
            pygame.draw.ellipse(s, (60, 45, 40), (x - 9, y - 7, 20, 18))
            pygame.draw.ellipse(s, (225, 215, 190), (x - 9, y - 11, 18, 22))
            pygame.draw.ellipse(s, (180, 160, 140), (x - 9, y - 11, 18, 22), 2)
            for k in range(3):
                pygame.draw.circle(s, (150, 120, 170), (x - 4 + k * 4, y - 3 + (k % 2) * 6), 2)
            if rng.probabilidad(0.4):
                pygame.draw.lines(s, (90, 70, 60), False, [(x - 3, y - 9), (x, y - 5), (x - 2, y - 2), (x + 2, y + 1)], 1)
    else:                                                # cripta
        degradado(s, (8, 30, 42), (32, 8, 52), (0, 0, ANCHO, TABLERO_ALTO))
        for _ in range(110):
            x, y = rng.entero(0, ANCHO), rng.entero(0, TABLERO_ALTO)
            col = (120, 255, 220) if rng.probabilidad(0.5) else (200, 140, 255)
            pygame.draw.circle(s, col, (x, y), 1)
        cx, cy = ANCHO // 2, TABLERO_ALTO // 2
        for r in (170, 152):
            pygame.draw.circle(s, (70, 36, 110), (cx, cy), r, 2)
        for k in range(5):
            a1, a2 = math.radians(-90 + k * 144), math.radians(-90 + (k + 1) * 144)
            pygame.draw.line(s, (70, 36, 110), (cx + 152 * math.cos(a1), cy + 152 * math.sin(a1)),
                             (cx + 152 * math.cos(a2), cy + 152 * math.sin(a2)), 2)
        for (ox, oy) in obstaculos:
            x, y = ox * CELDA + CELDA // 2, oy * CELDA + CELDA // 2
            pygame.draw.rect(s, (60, 70, 90), (x - 10, y - 11, 20, 22), border_radius=3)
            pygame.draw.rect(s, (120, 255, 220), (x - 10, y - 11, 20, 22), 1, border_radius=3)
            pygame.draw.line(s, (120, 255, 220), (x - 4, y - 5), (x + 4, y + 5), 1)
            pygame.draw.line(s, (120, 255, 220), (x + 4, y - 5), (x - 4, y + 5), 1)
    return s


def fruta_carmesi(s, c, t=0.0):
    """La fruta que permite devorar serpientes (nivel 4)."""
    x, y = px(c)
    pulso = 1 + 0.12 * math.sin(t * 7)
    halo(s, (x, y), int(30 * pulso), (255, 60, 80), 7, 22)
    pygame.draw.circle(s, (150, 10, 30), (x, y + 2), int(10 * pulso))
    pygame.draw.circle(s, (220, 30, 60), (x - 1, y + 1), int(8 * pulso))
    pygame.draw.circle(s, (255, 140, 150), (x - 4, y - 2), 2)
    for k in range(4):                                   # corona dorada
        pygame.draw.polygon(s, (255, 200, 60), [(x - 6 + k * 4, y - 7), (x - 4 + k * 4, y - 13), (x - 2 + k * 4, y - 7)])
    for k in range(3):                                   # chispas
        a = t * 3 + k * 2.1
        pygame.draw.circle(s, (255, 230, 120), (int(x + 15 * math.cos(a)), int(y + 15 * math.sin(a))), 2)


def mancha_niebla(rng):
    """Una nube de niebla hecha de círculos ubicados al azar."""
    w, h = 190, 110
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    for _ in range(9):
        pygame.draw.circle(s, (215, 222, 235, 26), (rng.entero(45, w - 45), rng.entero(35, h - 35)),
                           rng.entero(26, 44))
    return s


_cache_luz = {}


def agujero_luz(radio, oscuridad):
    """Círculo con degradado para 'recortar' la oscuridad (nivel 3)."""
    clave = (radio, oscuridad)
    if clave not in _cache_luz:
        s = pygame.Surface((radio * 2, radio * 2), pygame.SRCALPHA)
        s.fill((0, 0, 0, oscuridad))
        for r in range(radio, 0, -3):
            a = int(oscuridad * (r / radio) ** 1.8)
            pygame.draw.circle(s, (0, 0, 0, a), (radio, radio), r)
        _cache_luz[clave] = s
    return _cache_luz[clave]
