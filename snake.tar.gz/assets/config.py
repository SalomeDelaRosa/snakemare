# -*- coding: utf-8 -*-
"""Constantes del juego: tablero, dificultades y niveles."""
import sys

# True cuando el juego corre dentro del navegador (versión web hecha con pygbag)
WEB = sys.platform == "emscripten"

CELDA = 24
COLS, FILAS = 30, 20
HUD = 62                     # barra superior
PIE = 46                     # barra inferior (avance)
ANCHO = COLS * CELDA
ALTO = HUD + FILAS * CELDA + PIE
FPS = 60

ARRIBA, ABAJO, IZQ, DER = (0, -1), (0, 1), (-1, 0), (1, 0)
DIRS = [ARRIBA, ABAJO, IZQ, DER]

INICIO = [(5, 10), (4, 10), (3, 10), (2, 10)]        # cabeza primero
ZONA_SEGURA = {(x, y) for x in range(1, 11) for y in range(8, 13)}

PUNTOS_VIDA_EXTRA = 600

DIFICULTADES = {
    "Fácil":     dict(vel=6.5, vidas=4, mult=1.0, veneno=0.15, extra=0),
    "Normal":    dict(vel=8.0, vidas=3, mult=1.5, veneno=0.20, extra=1),
    "Pesadilla": dict(vel=9.5, vidas=2, mult=2.0, veneno=0.28, extra=2),
    # Supervivencia: niveles al azar, uno tras otro, hasta perder todas las vidas
    "Supervivencia": dict(vel=8.0, vidas=3, mult=2.0, veneno=0.22, extra=1, supervivencia=True),
}
ORDEN_DIF = ["Fácil", "Normal", "Pesadilla", "Supervivencia"]

NIVELES = {
    1: dict(nombre="EL CEMENTERIO", sub="Noche de luna llena", meta=5, color=(255, 150, 40),
            historia=["Tu serpiente despierta en una isla cubierta por una niebla eterna.",
                      "Entre las lápidas crecen calabazas... y alguna manzana envenenada.",
                      "Cuidado con los murciélagos: vuelan sin rumbo fijo."]),
    2: dict(nombre="EL BARCO FANTASMA", sub="Una isla perdida en la niebla", meta=7, color=(150, 230, 190),
            historia=["Un barco encallado cruje en la orilla. La niebla tapa la cubierta.",
                      "Serpientes zombi deambulan entre los barriles.",
                      "Si el piso tiembla, ¡aléjate! Una mano de esqueleto va a salir."]),
    3: dict(nombre="LA MANSIÓN OSCURA", sub="Solo ves lo que alumbra tu farol", meta=9, color=(230, 60, 70),
            historia=["Dentro de la mansión no hay luz. Tu farol se apaga poco a poco.",
                      "Recoge velas para ver más lejos y espera los relámpagos.",
                      "Dicen que a veces aparece una llave con forma de calavera..."]),
    4: dict(nombre="EL NIDO DE SERPIENTES", sub="Devora o serás devorada", meta=5, color=(235, 85, 160),
            historia=["Bajo la mansión se esconde el nido de las víboras.",
                      "Busca la fruta carmesí: mientras brilles, podrás devorarlas.",
                      "Devora 5 serpientes para escapar del nido."]),
    5: dict(nombre="LA CRIPTA", sub="Nivel secreto · el más allá", meta=11, color=(140, 255, 220),
            historia=["La llave calavera abrió la cripta bajo el nido.",
                      "Aquí eres un espíritu: puedes atravesar tu propio cuerpo.",
                      "Recoge las almas antes de que se esfumen y escapa del rey esqueleto."]),
}

# Colores generales
FONDO = (14, 10, 20)
TEXTO = (240, 235, 225)
TENUE = (165, 155, 175)
NARANJA = (255, 150, 40)
MORADO = (150, 90, 210)
VERDE_VENENO = (150, 255, 80)
