# Snakemare · La isla de la niebla eterna

Reto 2 de Modelamiento y Simulación. Es un Snake de terror con 4 niveles (5, 7 y 9 dulces; en el nivel 4 hay que devorar 5 serpientes) y un nivel secreto (11 almas). **Todo lo aleatorio sale de generadores hechos a mano**, sin `import random`.

## Cómo ejecutarlo

```
pip install pygame
(si tienes Python 3.14: pip install pygame-ce)
python serpiente_maldita.py
```

Los 6 archivos deben estar en la misma carpeta. El juego crea `serpiente_datos.json` para guardar el ranking y los niveles desbloqueados.

## Versión web

El juego también funciona en el navegador. El archivo `main.py` es la entrada para la web y los pasos para publicarlo están en `PUBLICAR_EN_LA_WEB.md`. En el computador se sigue abriendo con `python serpiente_maldita.py`.

## Poner tus propias canciones

Copia tus canciones (.mp3, .ogg o .wav) en la carpeta `musica`:

- Con nombre exacto: `menu.mp3`, `nivel1.mp3` … `nivel5.mp3` (nivel4 = Nido, nivel5 = Cripta). Cada una suena en su pantalla.
- Con cualquier otro nombre: en cada nivel, el generador asignado a "Música" elige una al azar.
- Si la carpeta no tiene canciones, el juego compone su propia música aleatoria.

## Archivos

| Archivo | Qué contiene |
|---|---|
| `generadores.py` | Los 3 generadores, las distribuciones (uniforme, entera, Bernoulli, discreta, exponencial y normal) y las pruebas chi², Kolmogorov-Smirnov y rachas |
| `juego.py` | La partida: generador de tableros, serpiente, enemigos, objetos y niveles |
| `dibujo.py` | Todos los gráficos, dibujados con código (sin imágenes) |
| `sonido.py` | Efectos sintetizados y música compuesta al azar |
| `config.py` | Constantes: niveles, dificultades y tamaño del tablero |
| `serpiente_maldita.py` | Programa principal: menú, pantallas y ranking |

Para ver las pruebas estadísticas en consola: `python generadores.py`

## Los 3 generadores (se eligen en el menú)

1. **Congruencias lineales** (visto en clase): X(n+1) = (a·Xn + c) mod m. En "Parámetros" hay dos opciones:
   - **De clase:** a = 1103515245, c = 12345, m = 2^31
   - **Elige tú:** el jugador escribe a, c y m, y el juego revisa en vivo el teorema de Hull-Dobell (periodo completo)
2. **Cuadrado medio** (visto en clase): Xn² y se toman los 8 dígitos centrales. Si se repite o llega a 0, se reinyecta la semilla. Es su debilidad conocida.
3. **Xorshift** (investigado por el equipo): Marsaglia, *Xorshift RNGs*, Journal of Statistical Software, 2003. Mezcla los bits del número con desplazamientos y XOR. Periodo 2^32 − 1.

### Un generador distinto para cada elemento

En **Menú → Generador por elemento** (o con la tecla **G** en la pausa, en plena partida) puedes asignar un generador diferente a cada parte del juego:

| Elemento | Qué controla |
|---|---|
| Tablero y obstáculos | Lápidas, barriles, muros, portales y dónde nacen los enemigos |
| Frutas y objetos | Qué fruta sale y dónde, veneno, velas, llave y almas |
| Enemigos | Movimiento de murciélagos, serpientes, calaveras y manos de esqueleto |
| Eventos | Relámpagos, destino de los portales, bono sorteado y efectos |
| Música | La melodía que se compone al azar en cada nivel |

Por ejemplo: las frutas con cuadrado medio, los enemigos con Xorshift y el tablero con congruencias lineales. Si no cambias nada, todos usan el "generador general". Cada elemento tiene su propia semilla derivada (semilla + k·1 000 003), así son flujos independientes pero reproducibles. En la pausa se ve qué generador usa cada elemento.

La **semilla** puede ser automática (el reloj, como en clase) o fija. Con una semilla fija se repite exactamente el mismo tablero, lo que sirve para mostrar que el juego es *pseudo*aleatorio.

## Nivel 4 · El Nido de Serpientes

Aparece al azar una **fruta carmesí** (el generador de "Frutas" decide dónde, y el tiempo entre una fruta y otra sigue una distribución exponencial). Al comerla, tu serpiente brilla en rojo durante unos segundos (Fácil 7 s, Normal 6 s, Pesadilla 5 s) y puede **devorar víboras**: mientras brillas, ellas se vuelven azules y huyen. **Al devorar 5 serpientes ganas el nivel.** Cada víbora devorada reaparece de 2 a 4 s después en un lugar al azar, lejos de ti. Si encontraste la llave calavera en el nivel 3, después del Nido entras a la Cripta (nivel 5).

## Modo Supervivencia

En Configurar → Dificultad → **Supervivencia**, el generador elige un nivel al azar (incluida la cripta). Al cumplir la meta, te lleva a otro nivel al azar, distinto al anterior, y así sin fin hasta que pierdas todas las vidas. La velocidad sube con cada ronda.

## Dónde se cumple cada requisito

| Requisito | En el juego |
|---|---|
| Elegir generador sin librerías | Menú → Generador general / Generador por elemento / Parámetros / Semilla. Archivo `generadores.py` |
| Música y sonidos | Música compuesta al azar con el generador elegido, con una escala distinta por nivel. 16 efectos sintetizados; el trueno y los golpes son ruido hecho con el generador |
| Movimiento aleatorio con el generador | Murciélagos y calaveras (caminata aleatoria), serpientes zombi y sombra (giro aleatorio o persecución con probabilidad p), niebla, portales con destino aleatorio |
| Teclado direccional | Flechas o WASD. P = pausa, M = sonido, F11 = pantalla completa |
| Conteo y tablero de puntos | Barra superior: puntos, récord y vidas |
| Velocidad según dificultad | Fácil, Normal, Pesadilla o Supervivencia. También sube con cada nivel (o ronda) y con cada dulce |
| Indicador de avance | Barra inferior (dulces comidos de la meta) y mapa de etapas 1 · 2 · 3 · ? |
| Generación de tableros / stages | Cada nivel genera obstáculos nuevos: lápidas, barriles, muros o pilares. Con BFS se revisa que todo el tablero sea alcanzable |
| Premios | Vida extra cada 600 puntos, bono por nivel completado y bono sorteado de 100 a 500 puntos al vencer la cripta |
| Ranking | Top 10 guardado en un archivo, con nombre, puntos, nivel, dificultad y generador |
| Diferentes enemigos | Murciélago, serpiente zombi, mano de esqueleto, serpiente sombra, víbora del nido, rey esqueleto y calavera flotante |
| Sistema de vidas | Calaveras en la barra superior. Al reaparecer la serpiente parpadea 3 s y es invulnerable: no la dañan enemigos y, si va a chocar, gira sola |
| Menú amigable | Menú principal con 4 opciones (Jugar, Configurar, Cómo jugar, Salir). Todo lo demás está en Configurar. Pantalla de pausa con la explicación de cada enemigo |

## Distribuciones de probabilidad que usa el juego

| Uso | Distribución | Función |
|---|---|---|
| Posición de comida y obstáculos | Uniforme discreta | `entero(a, b)` / `elegir(lista)` |
| ¿La fruta sale envenenada? (20 %) | Bernoulli | `probabilidad(p)` |
| ¿Calabaza (72 %) o caramelo (28 %)? | Discreta, por transformada inversa | `elegir_ponderado()` |
| Tiempo entre relámpagos y manos de esqueleto | Exponencial, por transformada inversa: −media·ln(1−U) | `exponencial(media)` |
| Bono final de 100 a 500 puntos | Uniforme discreta | `entero(1, 5)` × 100 |
| Llave del nivel secreto (12 %) | Bernoulli | `probabilidad(0.12)` |

## Características no funcionales extra

- Revisión de Hull-Dobell en vivo al escribir parámetros propios
- Semilla fija para reproducir partidas
- Temblor de pantalla al recibir daño, partículas, textos flotantes y objetos que parpadean antes de desaparecer
- Historia corta al empezar cada nivel
- Nivel secreto que se desbloquea y luego se puede elegir como nivel inicial
- Pantalla completa (F11) y modos de sonido
