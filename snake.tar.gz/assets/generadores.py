# -*- coding: utf-8 -*-
"""
  Vistos en clase:
    1. Cuadrado medio (Von Neumann, 1946)
    2. Congruencias lineales  X(n+1) = (a*Xn + c) mod m
       - con los parámetros de clase y con otros de la tabla de Wikipedia
       - con parámetros escritos por el jugador (se revisa Hull-Dobell)
  Investigado:
    3. Xorshift32 (Marsaglia, 2003): desplazamientos y XOR de bits

  Sobre cualquier generador se construyen las distribuciones que usa el
  juego (uniforme, entero, Bernoulli, discreta, exponencial, normal) y
  las pruebas estadísticas (chi-cuadrado, Kolmogorov-Smirnov y rachas).
==========================================================================
"""
import math
import time


def semilla_reloj():
    """'Automatizando la semilla' (clase): se toma del reloj del sistema."""
    return int(time.time() * 1_000_000) % 2_147_483_647 or 1


# ======================================================================
# CLASE BASE: distribuciones construidas sobre U(0,1)
# ======================================================================
class GeneradorBase:
    nombre = "Generador"
    origen = ""
    formula = ""

    def __init__(self, semilla=None):
        self.semilla = semilla_reloj() if semilla is None else int(semilla)
        self.generados = 0

    # --- lo único que cambia entre generadores -------------------------
    def _siguiente_u(self):
        raise NotImplementedError

    def estado(self):
        """Valor entero interno actual (para mostrar la tabla Xn)."""
        return 0

    # --- distribuciones --------------------------------------------------
    def uniforme(self):
        """U(0,1): número real en [0, 1)."""
        self.generados += 1
        u = self._siguiente_u()
        return u if u < 1.0 else 0.999999999

    def entero(self, minimo, maximo):
        """Uniforme discreta entre minimo y maximo (incluidos)."""
        return minimo + int(self.uniforme() * (maximo - minimo + 1))

    def real(self, minimo, maximo):
        """Uniforme continua U(minimo, maximo)."""
        return minimo + (maximo - minimo) * self.uniforme()

    def probabilidad(self, p):
        """Bernoulli(p): True con probabilidad p."""
        return self.uniforme() < p

    def elegir(self, secuencia):
        """Elige un elemento de la lista con igual probabilidad."""
        return secuencia[self.entero(0, len(secuencia) - 1)]

    def elegir_ponderado(self, opciones, pesos):
        """Distribución discreta por transformada inversa:
        se acumulan los pesos y se busca dónde cae U."""
        u = self.uniforme() * sum(pesos)
        acumulado = 0.0
        for opcion, peso in zip(opciones, pesos):
            acumulado += peso
            if u < acumulado:
                return opcion
        return opciones[-1]

    def barajar(self, lista):
        """Algoritmo de Fisher-Yates."""
        for i in range(len(lista) - 1, 0, -1):
            j = self.entero(0, i)
            lista[i], lista[j] = lista[j], lista[i]
        return lista

    def exponencial(self, media):
        """Transformada inversa:  X = -media * ln(1 - U).
        Se usa para el tiempo entre relámpagos y entre manos de esqueleto."""
        return -media * math.log(1.0 - self.uniforme())

    def normal(self, mu=0.0, sigma=1.0):
        """Método de Box-Muller."""
        u1 = max(self.uniforme(), 1e-12)
        u2 = self.uniforme()
        return mu + sigma * math.sqrt(-2 * math.log(u1)) * math.cos(2 * math.pi * u2)

# 1. CUADRADO MEDIO
class CuadradoMedio(GeneradorBase):
    nombre = "Cuadrado medio"
    origen = "Visto en clase · Von Neumann (1946)"
    formula = "X(n+1) = dígitos centrales de Xn²"

    def __init__(self, semilla=None, digitos=8):
        super().__init__(semilla)
        self.d = digitos
        self.x = self._ajustar(self.semilla)
        self.vistos = set()
        self.reinyecciones = 0

    def _ajustar(self, x):
        x %= 10 ** self.d
        if x < 10 ** (self.d - 1):                 # que tenga d dígitos
            x += 10 ** (self.d - 1)
        return x

    def _siguiente_u(self):
        cuadrado = str(self.x * self.x).zfill(2 * self.d)
        inicio = self.d // 2
        self.x = int(cuadrado[inicio:inicio + self.d])
        # Debilidad conocida: cae en cero o en ciclos cortos.
        # Si se repite un valor, se "reinyecta" una semilla nueva.
        if self.x == 0 or self.x in self.vistos:
            self.reinyecciones += 1
            self.x = self._ajustar(self.x * 7919 + 104729 + self.reinyecciones * 15485863)
            self.vistos.clear()
        self.vistos.add(self.x)
        if len(self.vistos) > 50_000:
            self.vistos.clear()
        return self.x / 10 ** self.d

    def estado(self):
        return self.x


# 2. CONGRUENCIAL LINEAL
class CongruencialLineal(GeneradorBase):
    nombre = "Congruencias lineales"
    origen = "Visto en clase"
    formula = "X(n+1) = (a·Xn + c) mod m"

    def __init__(self, semilla=None, a=1103515245, c=12345, m=2 ** 31, nombre=None, origen=None):
        super().__init__(semilla)
        self.a, self.c, self.m = int(a), int(c), int(m)
        if nombre:
            self.nombre = nombre
        if origen:
            self.origen = origen
        if self.c == 0:
            self.formula = "X(n+1) = (a·Xn) mod m   (multiplicativo)"
        self.x = self.semilla % self.m
        if self.c == 0 and self.x == 0:            # el multiplicativo no admite semilla 0
            self.x = 1

    def _siguiente_u(self):
        self.x = (self.a * self.x + self.c) % self.m
        return self.x / self.m

    def estado(self):
        return self.x


def factores_primos(n):
    factores, p = [], 2
    while p * p <= n:
        if n % p == 0:
            factores.append(p)
            while n % p == 0:
                n //= p
        p += 1
    if n > 1:
        factores.append(n)
    return factores


def hull_dobell(a, c, m):
    """Teorema de Hull-Dobell (periodo completo m). Devuelve (cumple, detalle)."""
    c1 = math.gcd(c, m) == 1
    c2 = all((a - 1) % p == 0 for p in factores_primos(m))
    c3 = (a - 1) % 4 == 0 if m % 4 == 0 else True
    return c1 and c2 and c3, (c1, c2, c3)

# 3. XORSHIFT32

class Xorshift32(GeneradorBase):
    """George Marsaglia, "Xorshift RNGs", Journal of Statistical Software 8(14), 2003.
    El estado es un entero de 32 bits; cada paso mezcla sus bits con tres
    desplazamientos (13, 17, 5) y la operación XOR. Periodo: 2^32 - 1.
    Es muy rápido y pasa más pruebas estadísticas que un congruencial simple."""
    nombre = "Xorshift"
    origen = "Investigado · Marsaglia (2003)"
    formula = "x ^= x<<13;  x ^= x>>17;  x ^= x<<5"

    MASCARA = 0xFFFFFFFF

    def __init__(self, semilla=None):
        super().__init__(semilla)
        self.x = (self.semilla & self.MASCARA) or 2463534242

    def _siguiente_u(self):
        x = self.x
        x ^= (x << 13) & self.MASCARA
        x ^= x >> 17
        x ^= (x << 5) & self.MASCARA
        self.x = x
        return x / 2 ** 32

    def estado(self):
        return self.x


# ======================================================================
# CATÁLOGO (lo que el jugador elige en el menú): 3 generadores
# ======================================================================
GENERADORES = [
    dict(clave="congruencial", titulo="Congruencias lineales", origen="Visto en clase"),
    dict(clave="cuadrado", titulo="Cuadrado medio", origen="Visto en clase"),
    dict(clave="xorshift", titulo="Xorshift", origen="Investigado por el equipo · Marsaglia 2003"),
]

# Parámetros de congruencias lineales: los de clase o los que escriba el jugador
PARAMETROS_LCG = [
    dict(clave="clase", titulo="De clase", a=1103515245, c=12345, m=2 ** 31),
    dict(clave="propio", titulo="Elige tú", a=1103515245, c=12345, m=32768),
]


def crear_generador(clave, semilla=None, params=None):
    """Fábrica: crea el generador elegido en el menú.
    params = dict(a, c, m, titulo) solo para el congruencial."""
    if clave == "cuadrado":
        return CuadradoMedio(semilla)
    if clave == "xorshift":
        return Xorshift32(semilla)
    p = params or PARAMETROS_LCG[0]
    return CongruencialLineal(semilla, p["a"], p["c"], p["m"],
                              nombre=f"Congruencias lineales · {p['titulo']}")


# ======================================================================
# PRUEBAS ESTADÍSTICAS (para el laboratorio del juego)
# ======================================================================
def prueba_chi_cuadrado(numeros, clases=10):
    """H0: los números son U(0,1). Crítico α=0.05 con 9 g.l. = 16.919"""
    n = len(numeros)
    frecuencias = [0] * clases
    for u in numeros:
        frecuencias[min(int(u * clases), clases - 1)] += 1
    esperado = n / clases
    chi2 = sum((o - esperado) ** 2 / esperado for o in frecuencias)
    return chi2, 16.919, chi2 < 16.919, frecuencias


def prueba_kolmogorov_smirnov(numeros):
    """D = máx |Fn(x) - x|. Crítico aproximado α=0.05: 1.36 / sqrt(n)"""
    ordenados = sorted(numeros)
    n = len(ordenados)
    d = 0.0
    for i, u in enumerate(ordenados, start=1):
        d = max(d, i / n - u, u - (i - 1) / n)
    critico = 1.36 / math.sqrt(n)
    return d, critico, d < critico


def prueba_rachas(numeros):
    """Rachas ascendentes y descendentes.
    E[R] = (2n-1)/3,  Var[R] = (16n-29)/90,  |Z| < 1.96 -> no se rechaza."""
    n = len(numeros)
    signos = [1 if numeros[i + 1] > numeros[i] else 0 for i in range(n - 1)]
    rachas = 1 + sum(1 for i in range(1, len(signos)) if signos[i] != signos[i - 1])
    media = (2 * n - 1) / 3
    var = (16 * n - 29) / 90
    z = (rachas - media) / math.sqrt(var)
    return rachas, z, abs(z) < 1.96


if __name__ == "__main__":
    # Demostración rápida en consola, al estilo del cuaderno de clase
    pruebas = [("cuadrado", None), ("xorshift", None)] + [("congruencial", p) for p in PARAMETROS_LCG]
    for clave, p in pruebas:
        gen = crear_generador(clave, semilla=12345, params=p)
        nums = [gen.uniforme() for _ in range(5000)]
        chi2, crit, ok, _ = prueba_chi_cuadrado(nums)
        d, dcrit, ok2 = prueba_kolmogorov_smirnov(nums)
        r, z, ok3 = prueba_rachas(nums)
        print(f"{gen.nombre:<45} chi2={chi2:6.2f} {'OK' if ok else '--'}  "
              f"KS={d:.4f} {'OK' if ok2 else '--'}  rachas z={z:+.2f} {'OK' if ok3 else '--'}")
    print("Hull-Dobell (clase, m=32768):", hull_dobell(1103515245, 12345, 32768))
