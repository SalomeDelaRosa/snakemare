# Publicar Snakemare en la web (itch.io)

El juego ya está adaptado para el navegador. Solo hay que generar la versión web y subirla.

## 1. Generar la versión web (en tu computador)

Abre una terminal **en la carpeta que contiene** la carpeta del juego `Snake` (es decir, en `Reto 2`) y escribe:

```
pip install pygbag
pygbag --build Snake
```

Se crea la carpeta `Snake/build/web` con dos archivos: `index.html` y `snake.apk`.

### (Opcional) Probarla antes de subirla

```
pygbag Snake
```

Abre en el navegador la dirección `http://localhost:8000`. Haz clic en la pantalla para empezar (los navegadores piden un clic antes de reproducir sonido). Para detenerlo, presiona Ctrl + C en la terminal.

## 2. Comprimir

Entra a `Snake/build/web`, selecciona **los dos archivos** (`index.html` y el `.apk`), clic derecho → **Comprimir en archivo ZIP**. El zip debe tener los archivos directamente, no una carpeta adentro.

## 3. Subir a itch.io (gratis)

1. Crea una cuenta en https://itch.io (o inicia sesión).
2. Arriba a la derecha: tu usuario → **Upload new project**.
3. Llena:
   - **Title:** Snakemare
   - **Kind of project:** **HTML**
   - **Uploads:** sube el zip y marca **"This file will be played in the browser"**
   - **Embed options → Viewport dimensions:** 720 × 588
   - Marca **"Click to launch in fullscreen"** si quieres que se abra grande (opcional)
   - **Visibility & access:** **Public** (o **Restricted** si solo quieres compartir el enlace)
4. **Save & view page.** El enlace queda como `https://tu-usuario.itch.io/snakemare`.

## Diferencias de la versión web

- El ranking y los niveles desbloqueados se guardan **en el navegador de cada persona**.
- No hay opción "Salir" (se cierra la pestaña) ni F11 (usa el botón de pantalla completa de itch.io).
- La música compuesta al azar es un poco más corta para que cargue rápido.
- Canciones propias: usa formato **.ogg** dentro de la carpeta `musica`.

## Si algo falla

| Problema | Solución |
|---|---|
| Pantalla negra o se queda cargando | Recarga la página. Revisa que el zip tenga `index.html` en la raíz |
| No suena | Haz clic dentro del juego; el navegador necesita un clic para activar el sonido. Luego prueba la tecla M |
| `pygbag` no se reconoce | Usa `python -m pygbag --build Snake` |
| Las teclas no responden | Haz clic sobre el juego para que tenga el foco |
