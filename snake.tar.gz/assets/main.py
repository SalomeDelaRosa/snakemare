# -*- coding: utf-8 -*-
"""
Punto de entrada para la VERSIÓN WEB (pygbag).
En el computador se sigue usando:  python serpiente_maldita.py

pygbag revisa los "import" de este archivo para saber qué librerías
descargar en el navegador; por eso pygame se importa aquí arriba.
"""
import asyncio

import pygame          # noqa: F401  (pygbag lo necesita aquí para cargar pygame)
import pygame.mixer    # noqa: F401  (y el sonido)

from serpiente_maldita import App


async def main():
    app = App(cargar_sonido=False)     # primero se muestra "Invocando la niebla..."
    await asyncio.sleep(0)             # el navegador dibuja la pantalla de carga
    app.iniciar_sonido()               # luego se crean los sonidos y la música
    await app.ejecutar_async()


asyncio.run(main())
