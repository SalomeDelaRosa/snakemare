# -*- coding: utf-8 -*-
"""
==========================================================================
   SNAKEMARE · La isla de la niebla eterna
   Reto 2 - Modelamiento y Simulación (generadores pseudoaleatorios)
==========================================================================
   Ejecutar:   pip install pygame
               python serpiente_maldita.py

   Archivos:
     generadores.py  -> los 3 generadores (sin librerías de azar) + pruebas estadísticas
     juego.py        -> lógica de la partida, enemigos y tableros
     dibujo.py       -> gráficos (todo dibujado con código)
     sonido.py       -> música aleatoria y efectos sintetizados
     config.py       -> constantes (niveles, dificultades)

   Controles:  Flechas o WASD = mover | P o Esc = pausa | M = sonido
               F11 = pantalla completa | Enter = elegir
==========================================================================
"""
import asyncio
import json
import math
import os
import sys
import time

import pygame

try:                      # en la versión web (pygbag) el módulo de sonido se importa aparte
    import pygame.mixer   # noqa: F401
except Exception:
    pass

import dibujo as D
from config import (ANCHO, ALTO, FPS, HUD, ARRIBA, ABAJO, IZQ, DER, ORDEN_DIF, NIVELES, DIFICULTADES, WEB,
                    FONDO, TEXTO, TENUE, NARANJA)
from generadores import GENERADORES, PARAMETROS_LCG, crear_generador, semilla_reloj, hull_dobell
from juego import Partida
from sonido import Sonidos

# Elementos del juego a los que se les puede asignar un generador distinto
CATEGORIAS = [
    ("tablero", "Tablero y obstáculos", "Lápidas, barriles, muros, portales y dónde nacen los enemigos"),
    ("frutas", "Frutas y objetos", "Qué fruta sale y dónde, veneno, velas, llave y almas"),
    ("enemigos", "Enemigos", "Movimiento de murciélagos, serpientes, calaveras y manos"),
    ("eventos", "Eventos", "Relámpagos, destino de portales, bono sorteado, efectos"),
    ("musica", "Música", "La melodía que se compone al azar en cada nivel"),
]
NOMBRE_CORTO = {"cuadrado": "Cuadrado medio", "congruencial": "Congruencias lineales", "xorshift": "Xorshift"}

CARPETA = os.path.dirname(os.path.abspath(__file__))
ARCHIVO_DATOS = os.path.join(CARPETA, "serpiente_datos.json")


# ======================================================================
# DATOS GUARDADOS (ranking, niveles desbloqueados, parámetros propios)
# ======================================================================
CLAVE_WEB = "snakemare_datos"          # en la web los datos se guardan en el navegador


def _almacen_web():
    """localStorage del navegador (solo existe en la versión web)."""
    try:
        import platform as plataforma_web          # en pygbag este módulo trae 'window'
        return plataforma_web.window.localStorage
    except Exception:
        return None


def cargar_datos():
    datos = {}
    try:
        if WEB:
            almacen = _almacen_web()
            texto = almacen.getItem(CLAVE_WEB) if almacen is not None else None
            datos = json.loads(texto) if texto else {}
        else:
            with open(ARCHIVO_DATOS, "r", encoding="utf-8") as f:
                datos = json.load(f)
    except (OSError, ValueError, TypeError):
        datos = {}
    datos.setdefault("ranking", [])
    datos.setdefault("nivel_max", 1)
    datos.setdefault("secreto", False)
    datos.setdefault("propio", dict(a=1103515245, c=12345, m=32768))
    return datos


def guardar_datos(datos):
    try:
        if WEB:
            almacen = _almacen_web()
            if almacen is not None:
                almacen.setItem(CLAVE_WEB, json.dumps(datos, ensure_ascii=False))
        else:
            with open(ARCHIVO_DATOS, "w", encoding="utf-8") as f:
                json.dump(datos, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


# ======================================================================
# APLICACIÓN
# ======================================================================
class App:
    def __init__(self, cargar_sonido=True):
        try:
            # En la web el navegador necesita un búfer grande; con 512 el audio se entrecorta y suena distorsionado
            pygame.mixer.pre_init(22050, -16, 1, 4096 if WEB else 512)
        except Exception:
            pass                                        # sin sonido: el juego sigue funcionando
        pygame.init()
        if WEB:
            try:   # el juego no usa el mouse; ignorarlo evita trabajo extra del navegador en cada movimiento
                pygame.event.set_blocked([pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP,
                                          pygame.MOUSEWHEEL])
            except Exception:
                pass
        try:
            if WEB:                                     # en la web el navegador escala el lienzo
                self.pantalla = pygame.display.set_mode((ANCHO, ALTO))
            else:
                self.pantalla = pygame.display.set_mode((ANCHO, ALTO), pygame.SCALED)
        except pygame.error:
            self.pantalla = pygame.display.set_mode((ANCHO, ALTO))
        pygame.display.set_caption("Snakemare · La isla de la niebla eterna")
        self.lienzo = pygame.Surface((ANCHO, ALTO))
        self.reloj = pygame.time.Clock()
        self.f = {"titulo": pygame.font.Font(None, 64), "t": pygame.font.Font(None, 34),
                  "g": pygame.font.Font(None, 40), "m": pygame.font.Font(None, 28),
                  "p": pygame.font.Font(None, 22), "pp": pygame.font.Font(None, 19)}

        self.datos = cargar_datos()
        self.i_gen = 0                      # Congruencias lineales por defecto
        self.i_param = 0                    # parámetros de clase
        self.asignacion = {c[0]: None for c in CATEGORIAS}   # None = usa el generador general
        self.sel_asig = 0
        self.sel_cfg = 0
        self.volver = "menu"
        self.volver_asig = "config"
        self.semilla_manual = None
        self.dificultad = "Normal"
        self.nivel_inicial = 1
        self.estado = "menu"
        self.sel = 0
        self.partida = None
        self.t = 0.0
        self.aviso_txt, self.t_aviso = "", 0.0
        self.entrada = ""
        self.campo = 0
        self.campos = ["", "", ""]
        self.siguiente_nivel = None

        self.lienzo.fill(FONDO)
        D.texto(self.lienzo, "Invocando la niebla...", self.f["m"], TENUE, centro=(ANCHO // 2, ALTO // 2))
        self.presentar()
        self.rng_menu = self.generador(semilla_reloj())
        self.musica_menu = None
        if cargar_sonido:
            self.iniciar_sonido()
        else:
            self.snd = Sonidos(None, crear=False)          # se crea después (versión web)
        self.fondo_menu = D.construir_fondo(1, set(), self.generador(semilla_reloj()))

    # ------------------------------------------------------------------ generador elegido
    def params_lcg(self):
        p = dict(PARAMETROS_LCG[self.i_param])
        if p["clave"] == "propio":
            p.update(self.datos["propio"])
        return p

    def generador(self, semilla=None):
        clave = GENERADORES[self.i_gen]["clave"]
        return crear_generador(clave, semilla, self.params_lcg() if clave == "congruencial" else None)

    def clave_de(self, categoria):
        i = self.asignacion[categoria]
        return GENERADORES[self.i_gen if i is None else i]["clave"]

    def generador_de(self, categoria, semilla=None):
        """Generador asignado a un elemento del juego (frutas, enemigos, ...)."""
        clave = self.clave_de(categoria)
        return crear_generador(clave, semilla, self.params_lcg() if clave == "congruencial" else None)

    def crear_rngs(self, semilla):
        """Un generador por elemento. Cada uno con su propia semilla derivada,
        así son flujos independientes pero reproducibles con la misma semilla."""
        rngs = {}
        for k, (cat, _, _) in enumerate(CATEGORIAS):
            rngs[cat] = self.generador_de(cat, (semilla + k * 1_000_003) % 2_147_483_647 or 1)
        return rngs

    def usa_lcg(self):
        return "congruencial" in {self.clave_de(c[0]) for c in CATEGORIAS}

    def es_mixto(self):
        return len({self.clave_de(c[0]) for c in CATEGORIAS}) > 1

    def nombre_partida(self):
        return "Generadores mixtos" if self.es_mixto() else self.nombre_generador(corto=True)

    def nombre_asignado(self, categoria):
        clave = self.clave_de(categoria)
        if clave == "congruencial":
            return "Congruencias · " + self.params_lcg()["titulo"]
        return NOMBRE_CORTO[clave]

    def nombre_generador(self, corto=False):
        g = GENERADORES[self.i_gen]
        if g["clave"] == "congruencial":
            return ("Congruencias · " if corto else "Congruencias lineales · ") + self.params_lcg()["titulo"]
        return g["titulo"]

    def iniciar_sonido(self):
        """Sintetiza los efectos y compone la música del menú."""
        self.snd = Sonidos(self.generador(semilla_reloj()))
        self.poner_musica("menu", self.rng_menu)

    # ------------------------------------------------------------------ música
    def poner_musica(self, clave, rng):
        """Si hay canciones en la carpeta 'musica', toca una (elegida con el generador).
        Si no hay, compone una melodía aleatoria."""
        cancion = self.snd.buscar_cancion(clave, rng)
        if cancion and self.snd.tocar_archivo(cancion):
            return
        if clave == "menu":
            if self.musica_menu is None:
                self.musica_menu = self.snd.componer("menu", rng)
            self.snd.tocar_musica(self.musica_menu)
        else:
            self.snd.tocar_musica(self.snd.componer(clave, rng))

    # ------------------------------------------------------------------ utilidades
    def presentar(self):
        self.pantalla.blit(self.lienzo, (0, 0))
        pygame.display.flip()

    def avisar(self, msg):
        self.aviso_txt, self.t_aviso = msg, 3.0

    def record(self):
        return max([r["puntos"] for r in self.datos["ranking"]] or [0])

    def niveles_disponibles(self):
        niveles = list(range(1, min(4, self.datos["nivel_max"]) + 1))
        if self.datos["secreto"]:
            niveles.append(5)
        return niveles

    def opciones_menu(self):
        if self.estado != "config":
            principal = [("jugar", "Jugar"), ("config", "Configurar"), ("ayuda", "Cómo jugar")]
            return principal if WEB else principal + [("salir", "Salir")]   # en la web no se "sale"
        es_lcg = self.usa_lcg()
        semilla = "Automática (reloj)" if self.semilla_manual is None else str(self.semilla_manual)
        nivel = "Cripta (secreto)" if self.nivel_inicial == 5 else str(self.nivel_inicial)
        if DIFICULTADES[self.dificultad].get("supervivencia"):
            nivel = "al azar (supervivencia)"
        return [
            ("gen", f"Generador general:  < {GENERADORES[self.i_gen]['titulo']} >"),
            ("asignar", "Generador por elemento:  " + ("personalizado" if self.es_mixto() else "todo igual")),
            ("param", f"Parámetros:  < {self.params_lcg()['titulo']} >" if es_lcg else "Parámetros:  (solo congruencias lineales)"),
            ("semilla", f"Semilla:  {semilla}"),
            ("dif", f"Dificultad:  < {self.dificultad} >"),
            ("nivel", f"Nivel inicial:  < {nivel} >"),
            ("ranking", "Ranking de jugadores"),
            ("sonido", f"Sonido:  < {self.snd.modo()} >"),
            ("volver", "Volver"),
        ]

    # ------------------------------------------------------------------ bucle
    def un_cuadro(self, extra=()):
        """Un cuadro del juego: leer teclas, actualizar y dibujar. False = salir."""
        dt = min(self.reloj.tick(FPS) / 1000.0, 1 / 20)
        self.t += dt
        for e in pygame.event.get() + list(extra):
            if e.type == pygame.QUIT:
                return False
            if e.type == pygame.KEYDOWN and self.tecla(e) == "salir":
                return False
        self.actualizar(dt)
        self.dibujar()
        return True

    def ejecutar(self, max_cuadros=None, guion=None):
        """Versión de escritorio."""
        cuadro = 0
        while self.un_cuadro(guion(cuadro, self) if guion else ()):
            cuadro += 1
            if max_cuadros and cuadro >= max_cuadros:
                break
        return self.salir()

    async def ejecutar_async(self, max_cuadros=None):
        """Versión web: en cada cuadro le devuelve el control al navegador."""
        cuadro = 0
        while self.un_cuadro():
            await asyncio.sleep(0)
            cuadro += 1
            if max_cuadros and cuadro >= max_cuadros:
                break
        self.salir()

    def salir(self):
        guardar_datos(self.datos)
        pygame.quit()

    # ------------------------------------------------------------------ teclado
    def tecla(self, e):
        k = e.key
        escribiendo = self.estado in ("semilla", "nombre", "parametros")
        if k == pygame.K_F11 and not WEB:
            try:
                pygame.display.toggle_fullscreen()
            except pygame.error:
                pass
            return None
        if k == pygame.K_m and not escribiendo:
            self.snd.ciclar_modo()
            self.avisar(f"Sonido: {self.snd.modo()}")
            return None
        metodo = getattr(self, "tecla_" + self.estado, None)
        return metodo(e) if metodo else None

    def seleccion(self):
        return self.sel_cfg if self.estado == "config" else self.sel

    def mover_seleccion(self, paso):
        n = len(self.opciones_menu())
        if self.estado == "config":
            self.sel_cfg = (self.sel_cfg + paso) % n
        else:
            self.sel = (self.sel + paso) % n
        self.snd.play("menu")

    def tecla_menu(self, e):
        k = e.key
        ops = self.opciones_menu()
        clave = ops[self.seleccion()][0]
        if k in (pygame.K_UP, pygame.K_w):
            self.mover_seleccion(-1)
        elif k in (pygame.K_DOWN, pygame.K_s):
            self.mover_seleccion(1)
        elif k in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d):
            self.cambiar_opcion(clave, 1 if k in (pygame.K_RIGHT, pygame.K_d) else -1)
        elif k in (pygame.K_RETURN, pygame.K_SPACE):
            return self.elegir(clave)
        elif k == pygame.K_ESCAPE:
            if self.estado == "config":
                self.estado = "menu"
            elif not WEB:
                return "salir"
        return None

    tecla_config = tecla_menu

    def cambiar_opcion(self, clave, paso):
        self.snd.play("menu")
        if clave == "gen":
            self.i_gen = (self.i_gen + paso) % len(GENERADORES)
        elif clave == "param" and self.usa_lcg():
            self.i_param = (self.i_param + paso) % len(PARAMETROS_LCG)
        elif clave == "dif":
            self.dificultad = ORDEN_DIF[(ORDEN_DIF.index(self.dificultad) + paso) % len(ORDEN_DIF)]
        elif clave == "nivel":
            niv = self.niveles_disponibles()
            i = niv.index(self.nivel_inicial) if self.nivel_inicial in niv else 0
            self.nivel_inicial = niv[(i + paso) % len(niv)]
        elif clave == "sonido":
            self.snd.ciclar_modo()

    def elegir(self, clave):
        if clave == "jugar":
            self.empezar_partida()
        elif clave == "config":
            self.sel_cfg = 0
            self.estado = "config"
        elif clave == "volver":
            self.estado = "menu"
        elif clave in ("gen", "dif", "nivel", "sonido"):
            self.cambiar_opcion(clave, 1)
        elif clave == "param":
            if not self.usa_lcg():
                self.avisar("Los parámetros solo aplican a congruencias lineales")
            elif PARAMETROS_LCG[self.i_param]["clave"] == "propio":
                p = self.datos["propio"]
                self.campos = [str(p["a"]), str(p["c"]), str(p["m"])]
                self.campo = 0
                self.estado = "parametros"
            else:
                self.cambiar_opcion(clave, 1)
        elif clave == "semilla":
            self.entrada = "" if self.semilla_manual is None else str(self.semilla_manual)
            self.estado = "semilla"
        elif clave == "asignar":
            self.abrir_asignacion("config")
        elif clave in ("ranking", "ayuda"):
            self.volver = self.estado
            self.estado = clave
        elif clave == "salir":
            return "salir"
        return None

    def tecla_semilla(self, e):
        if e.key == pygame.K_RETURN:
            self.semilla_manual = int(self.entrada) if self.entrada else None
            self.avisar("Semilla automática" if self.semilla_manual is None
                        else f"Semilla fija {self.semilla_manual}: el mismo tablero se repetirá")
            self.estado = "config"
        elif e.key == pygame.K_ESCAPE:
            self.estado = "config"
        elif e.key == pygame.K_BACKSPACE:
            self.entrada = self.entrada[:-1]
        elif e.unicode.isdigit() and len(self.entrada) < 10:
            self.entrada += e.unicode

    def tecla_parametros(self, e):
        if e.key in (pygame.K_TAB, pygame.K_DOWN):
            self.campo = (self.campo + 1) % 3
        elif e.key == pygame.K_UP:
            self.campo = (self.campo - 1) % 3
        elif e.key == pygame.K_ESCAPE:
            self.estado = "config"
        elif e.key == pygame.K_BACKSPACE:
            self.campos[self.campo] = self.campos[self.campo][:-1]
        elif e.key == pygame.K_RETURN:
            if self.campo < 2:
                self.campo += 1
                return
            try:
                a, c, m = (int(x) for x in self.campos)
            except ValueError:
                self.avisar("Escribe los tres números")
                return
            if not (m >= 2 and 0 < a < m and 0 <= c < m):
                self.avisar("Revisa: m ≥ 2, 0 < a < m y 0 ≤ c < m")
                return
            self.datos["propio"] = dict(a=a, c=c, m=m)
            guardar_datos(self.datos)
            self.avisar("Parámetros guardados")
            self.estado = "config"
        elif e.unicode.isdigit() and len(self.campos[self.campo]) < 12:
            self.campos[self.campo] += e.unicode

    def tecla_transicion(self, e):
        if e.key in (pygame.K_RETURN, pygame.K_SPACE):
            self.partida.iniciar_nivel(self.siguiente_nivel)
            self.estado = "jugando"
        elif e.key == pygame.K_ESCAPE:
            self.terminar_partida()

    def tecla_jugando(self, e):
        dirs = {pygame.K_UP: ARRIBA, pygame.K_w: ARRIBA, pygame.K_DOWN: ABAJO, pygame.K_s: ABAJO,
                pygame.K_LEFT: IZQ, pygame.K_a: IZQ, pygame.K_RIGHT: DER, pygame.K_d: DER}
        if e.key in dirs:
            self.partida.girar(dirs[e.key])
        elif e.key in (pygame.K_p, pygame.K_ESCAPE):
            self.estado = "pausa"

    def tecla_pausa(self, e):
        if e.key in (pygame.K_p, pygame.K_ESCAPE, pygame.K_RETURN):
            self.estado = "jugando"
        elif e.key == pygame.K_g:
            self.abrir_asignacion("pausa")
        elif e.key == pygame.K_q:
            self.terminar_partida()

    # --- generador por elemento ------------------------------------------
    def abrir_asignacion(self, volver):
        self.volver_asig = volver
        self.antes_asig = {c[0]: self.clave_de(c[0]) for c in CATEGORIAS}
        self.antes_params = self.params_lcg()
        self.sel_asig = 0
        self.estado = "asignar"

    def tecla_asignar(self, e):
        k = e.key
        n = len(CATEGORIAS)
        if k in (pygame.K_UP, pygame.K_w):
            self.sel_asig = (self.sel_asig - 1) % n
            self.snd.play("menu")
        elif k in (pygame.K_DOWN, pygame.K_s):
            self.sel_asig = (self.sel_asig + 1) % n
            self.snd.play("menu")
        elif k in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d):
            cat = CATEGORIAS[self.sel_asig][0]
            opciones = [None] + list(range(len(GENERADORES)))
            i = opciones.index(self.asignacion[cat])
            paso = 1 if k in (pygame.K_RIGHT, pygame.K_d) else -1
            self.asignacion[cat] = opciones[(i + paso) % len(opciones)]
            self.snd.play("menu")
        elif k == pygame.K_r:
            self.asignacion = {c[0]: None for c in CATEGORIAS}
            self.avisar("Todos los elementos usan el generador general")
        elif k in (pygame.K_RETURN, pygame.K_ESCAPE, pygame.K_SPACE):
            self.cerrar_asignacion()

    def cerrar_asignacion(self):
        if self.volver_asig == "pausa" and self.partida:
            cambiados = []
            for cat, nombre, _ in CATEGORIAS:
                if self.clave_de(cat) != self.antes_asig[cat] or (
                        self.clave_de(cat) == "congruencial" and self.params_lcg() != self.antes_params):
                    cambiados.append(nombre)
                    if cat == "musica":
                        self.rng_musica = self.generador_de("musica", semilla_reloj())
                        self.poner_musica(self.partida.nivel, self.rng_musica)
                    else:
                        self.partida.cambiar_generador(cat, self.generador_de(cat, semilla_reloj()))
            self.partida.nombre_gen = self.nombre_partida()
            if cambiados:
                self.avisar("Cambiaste el generador de: " + ", ".join(cambiados))
        self.estado = self.volver_asig

    def tecla_victoria(self, e):
        if e.key in (pygame.K_RETURN, pygame.K_SPACE):
            self.terminar_partida()

    def tecla_nombre(self, e):
        if e.key == pygame.K_RETURN:
            self.guardar_ranking(self.entrada.strip() or "Anónimo")
        elif e.key == pygame.K_BACKSPACE:
            self.entrada = self.entrada[:-1]
        elif e.unicode and e.unicode.isprintable() and len(self.entrada) < 12:
            self.entrada += e.unicode

    def tecla_simple(self, e):
        if e.key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_SPACE):
            self.estado = self.volver if self.estado in ("ranking", "ayuda") else "menu"
            self.volver = "menu"

    tecla_ranking = tecla_ayuda = tecla_gameover = tecla_simple

    # ------------------------------------------------------------------ partida
    def empezar_partida(self):
        semilla = self.semilla_manual if self.semilla_manual is not None else semilla_reloj()
        self.semilla_partida = semilla
        rngs = self.crear_rngs(semilla)
        self.rng_musica = rngs.pop("musica")
        self.partida = Partida(rngs, self.dificultad, self.snd, self.nombre_partida())
        if self.partida.supervivencia:
            self.ir_a_transicion(self.partida.rng.elegir([1, 2, 3, 4, 5]))   # primer nivel al azar
        else:
            self.ir_a_transicion(self.nivel_inicial)

    def ir_a_transicion(self, nivel):
        self.siguiente_nivel = nivel
        self.estado = "transicion"
        self.snd.detener_musica()
        self.dibujar(componiendo=True)
        self.poner_musica(nivel, self.rng_musica)
        if self.partida.supervivencia:
            pass                                           # en supervivencia no se desbloquea nada
        elif nivel <= 4:
            self.datos["nivel_max"] = max(self.datos["nivel_max"], nivel)
        else:
            self.datos["secreto"] = True
        guardar_datos(self.datos)

    def terminar_partida(self):
        p = self.partida
        self.poner_musica("menu", self.rng_menu)
        rk = self.datos["ranking"]
        if p.puntos > 0 and (len(rk) < 10 or p.puntos > min(r["puntos"] for r in rk)):
            self.entrada = ""
            self.estado = "nombre"
        else:
            self.estado = "gameover"

    def guardar_ranking(self, nombre):
        p = self.partida
        self.datos["ranking"].append(dict(nombre=nombre, puntos=p.puntos, nivel=p.nivel_max,
                                          dificultad=p.nombre_dif, generador=p.nombre_gen,
                                          fecha=time.strftime("%Y-%m-%d")))
        self.datos["ranking"].sort(key=lambda r: -r["puntos"])
        self.datos["ranking"] = self.datos["ranking"][:10]
        guardar_datos(self.datos)
        self.estado = "ranking"

    # ------------------------------------------------------------------ laboratorio
    # ------------------------------------------------------------------ actualizar
    def actualizar(self, dt):
        self.t_aviso = max(0.0, self.t_aviso - dt)
        if self.estado == "jugando":
            p = self.partida
            p.actualizar(dt)
            if p.terminada:
                self.snd.play("fin")
                self.terminar_partida()
            elif p.evento:
                _, siguiente = p.evento
                if siguiente:
                    self.ir_a_transicion(siguiente)
                else:
                    self.snd.play("victoria")
                    self.estado = "victoria"

    # ------------------------------------------------------------------ dibujar
    def dibujar(self, componiendo=False):
        s = self.lienzo
        s.fill(FONDO)
        if self.estado == "transicion":
            self.dibujar_transicion(componiendo)
        else:
            getattr(self, "dibujar_" + self.estado)()
        if self.t_aviso > 0:
            r = D.texto(s, self.aviso_txt, self.f["p"], (255, 210, 90), centro=(ANCHO // 2, ALTO - 18))
            pygame.draw.rect(s, (255, 210, 90), r.inflate(18, 8), 1, border_radius=6)
        dx = dy = 0
        if self.estado == "jugando" and self.partida.shake > 0:     # temblor de pantalla
            dx = self.partida.rng.entero(-5, 5)
            dy = self.partida.rng.entero(-5, 5)
        self.pantalla.fill((0, 0, 0))
        self.pantalla.blit(s, (dx, dy))
        pygame.display.flip()

    def capa(self, alfa=180):
        c = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        c.fill((8, 5, 12, alfa))
        self.lienzo.blit(c, (0, 0))

    def titulo(self, txt, color=NARANJA, y=46):
        D.texto(self.lienzo, txt, self.f["g"], color, centro=(ANCHO // 2, y), sombra=True)

    def dibujar_menu(self):
        s = self.lienzo
        s.blit(self.fondo_menu, (0, 0))
        self.capa(170)
        D.murcielago(s, 90 + 20 * math.sin(self.t), 40, self.t, 1.3)
        D.murcielago(s, ANCHO - 100, 52 + 10 * math.sin(self.t * 1.3), self.t + 1, 1.0)
        D.texto(s, "SNAKEMARE", self.f["titulo"], NARANJA, centro=(ANCHO // 2, 52), sombra=True)
        D.texto(s, "La isla de la niebla eterna", self.f["m"], TENUE, centro=(ANCHO // 2, 92))
        D.texto(s, f"Récord: {self.record()}", self.f["p"], TEXTO, der=(ANCHO - 14, 118))
        config = self.estado in ("config", "semilla", "parametros")
        if config:
            D.texto(s, "CONFIGURACIÓN", self.f["t"], NARANJA, centro=(ANCHO // 2, 140))
        ops = self.opciones_menu() if not config else self.opciones_config()
        y0, paso, fuente, ancho = (185, 36, self.f["m"], 500) if config else (230, 62, self.f["g"], 330)
        for i, (clave, op) in enumerate(ops):
            y = y0 + i * paso
            activo = i == (self.sel_cfg if config else self.sel)
            apagado = clave == "param" and not self.usa_lcg()
            if activo:
                caja = pygame.Rect(0, 0, ancho, paso - 6)
                caja.center = (ANCHO // 2, y)
                pygame.draw.rect(s, (55, 30, 70), caja, border_radius=9)
                pygame.draw.rect(s, NARANJA, caja, 2, border_radius=9)
            col = (95, 85, 105) if apagado else (NARANJA if activo else TEXTO)
            D.texto(s, op, fuente, col, centro=(ANCHO // 2, y))
        if self.t_aviso <= 0:
            D.texto(s, "Flechas arriba/abajo: moverse · izq./der.: cambiar · Enter: elegir · M: sonido"
                    + ("" if WEB else " · F11: pantalla completa"),
                    self.f["pp"], (120, 110, 130), centro=(ANCHO // 2, ALTO - 18))

    dibujar_config = dibujar_menu

    def opciones_config(self):
        estado, self.estado = self.estado, "config"
        ops = self.opciones_menu()
        self.estado = estado
        return ops

    def dibujar_semilla(self):
        self.dibujar_menu()
        self.capa(245)
        self.titulo("SEMILLA DEL GENERADOR", NARANJA, 170)
        D.texto(self.lienzo, "Escribe un número (vacío = automática con el reloj)", self.f["m"], TENUE,
                centro=(ANCHO // 2, 220))
        D.texto(self.lienzo, "Con la misma semilla se repiten el tablero y los enemigos.", self.f["p"], TENUE,
                centro=(ANCHO // 2, 248))
        caja = pygame.Rect(0, 0, 320, 52)
        caja.center = (ANCHO // 2, 310)
        pygame.draw.rect(self.lienzo, NARANJA, caja, 2, border_radius=8)
        cursor = "_" if int(self.t * 2) % 2 == 0 else " "
        D.texto(self.lienzo, self.entrada + cursor, self.f["g"], TEXTO, centro=caja.center)
        D.texto(self.lienzo, "Enter: guardar     Esc: volver", self.f["p"], TENUE, centro=(ANCHO // 2, 380))

    def dibujar_parametros(self):
        s = self.lienzo
        self.dibujar_menu()
        self.capa(248)
        self.titulo("CONGRUENCIAS LINEALES · ELIGE TÚ", NARANJA, 120)
        D.texto(s, "X(n+1) = (a · Xn + c) mod m", self.f["m"], TEXTO, centro=(ANCHO // 2, 160))
        for i, nombre in enumerate(["a (multiplicador)", "c (incremento)", "m (módulo)"]):
            y = 215 + i * 62
            D.texto(s, nombre, self.f["m"], TENUE, der=(300, y - 10))
            caja = pygame.Rect(320, y - 24, 260, 44)
            pygame.draw.rect(s, NARANJA if i == self.campo else (90, 80, 100), caja, 2, border_radius=8)
            cursor = "_" if i == self.campo and int(self.t * 2) % 2 == 0 else ""
            D.texto(s, self.campos[i] + cursor, self.f["m"], TEXTO, pos=(334, y - 12))
        try:
            a, c, m = (int(x) for x in self.campos)
            ok, (c1, c2, c3) = hull_dobell(a, c, m) if m >= 2 else (False, (False, False, False))
            txt = "Cumple Hull-Dobell: periodo completo" if ok else "No cumple Hull-Dobell: el periodo será menor que m"
            D.texto(s, txt, self.f["m"], (130, 230, 140) if ok else (240, 130, 110), centro=(ANCHO // 2, 420))
            D.texto(s, f"mcd(c, m) = 1: {'sí' if c1 else 'no'}   ·   a-1 divisible por los primos de m: "
                       f"{'sí' if c2 else 'no'}   ·   si 4|m, 4|(a-1): {'sí' if c3 else 'no'}",
                    self.f["pp"], TENUE, centro=(ANCHO // 2, 450))
        except ValueError:
            pass
        D.texto(s, "Tab o flechas: cambiar campo   Enter: siguiente / guardar   Esc: volver", self.f["p"], TENUE,
                centro=(ANCHO // 2, 510))

    def dibujar_asignar(self):
        s = self.lienzo
        if self.volver_asig == "pausa":
            self.dibujar_jugando()
        else:
            s.blit(self.fondo_menu, (0, 0))
        self.capa(238)
        self.titulo("GENERADOR POR ELEMENTO", NARANJA, 44)
        D.texto(s, "Elige qué generador controla cada parte del juego", self.f["m"], TENUE, centro=(ANCHO // 2, 82))
        for i, (cat, nombre, desc) in enumerate(CATEGORIAS):
            y = 135 + i * 72
            activo = i == self.sel_asig
            if activo:
                caja = pygame.Rect(30, y - 20, ANCHO - 60, 62)
                pygame.draw.rect(s, (55, 30, 70), caja, border_radius=10)
                pygame.draw.rect(s, NARANJA, caja, 2, border_radius=10)
            D.texto(s, nombre, self.f["m"], NARANJA if activo else TEXTO, pos=(50, y - 10))
            D.texto(s, desc, self.f["pp"], TENUE, pos=(50, y + 16))
            valor = self.asignacion[cat]
            if valor is None:
                txt, col = f"General ({NOMBRE_CORTO[self.clave_de(cat)]})", TENUE
            else:
                txt, col = GENERADORES[valor]["titulo"], (255, 210, 90)
            D.texto(s, f"<  {txt}  >", self.f["m"], col, der=(ANCHO - 50, y - 6))
        g = GENERADORES[self.i_gen]
        D.texto(s, f"General: {self.nombre_generador()}   ·   Parámetros de congruencias: {self.params_lcg()['titulo']}",
                self.f["pp"], TENUE, centro=(ANCHO // 2, ALTO - 66))
        extra = "Los cambios se aplican al volver a la partida" if self.volver_asig == "pausa" else "Origen: " + g["origen"]
        D.texto(s, extra, self.f["pp"], (200, 160, 255), centro=(ANCHO // 2, ALTO - 46))
        if self.t_aviso <= 0:
            D.texto(s, "Arriba/Abajo: elemento   Izq./Der.: generador   R: todo igual   Enter: listo",
                    self.f["p"], TENUE, centro=(ANCHO // 2, ALTO - 20))

    def dibujar_transicion(self, componiendo=False):
        s = self.lienzo
        n = self.siguiente_nivel
        cfg = NIVELES[n]
        fondo = D.construir_fondo(n, set(), self.partida.rngs["tablero"]) if componiendo or not hasattr(self, "_fondo_tr") \
            or self._fondo_tr[0] != n else self._fondo_tr[1]
        self._fondo_tr = (n, fondo)
        s.blit(fondo, (0, HUD))
        self.capa(185)
        etiqueta = "NIVEL SECRETO" if n == 5 else f"NIVEL {n}"
        if self.partida.supervivencia:
            etiqueta = f"SUPERVIVENCIA · RONDA {self.partida.ronda + 1}"
        D.texto(s, etiqueta, self.f["t"], TENUE, centro=(ANCHO // 2, 120))
        D.texto(s, cfg["nombre"], self.f["titulo"], cfg["color"], centro=(ANCHO // 2, 170), sombra=True)
        D.texto(s, cfg["sub"], self.f["m"], TENUE, centro=(ANCHO // 2, 212))
        for i, linea in enumerate(cfg["historia"]):
            D.texto(s, linea, self.f["m"], TEXTO, centro=(ANCHO // 2, 275 + i * 34))
        unidad = {4: "serpientes devoradas", 5: "almas"}.get(n, "dulces")
        D.texto(s, f"Meta: {cfg['meta']} {unidad}", self.f["m"], cfg["color"],
                centro=(ANCHO // 2, 395))
        p = self.partida
        D.texto(s, f"Generador: {self.nombre_partida()}   ·   Semilla: {self.semilla_partida}",
                self.f["p"], TENUE, centro=(ANCHO // 2, 440))
        if componiendo:
            D.texto(s, "Componiendo música aleatoria...", self.f["m"], TENUE, centro=(ANCHO // 2, 500))
        elif int(self.t * 2) % 2 == 0:
            D.texto(s, "Presiona Enter para entrar", self.f["m"], TEXTO, centro=(ANCHO // 2, 500))
        if p.puntos:
            D.texto(s, f"Puntos: {p.puntos}   Vidas: {p.vidas}", self.f["p"], TEXTO, centro=(ANCHO // 2, 535))
        if componiendo:
            self.pantalla.blit(s, (0, 0))
            pygame.display.flip()

    def dibujar_jugando(self):
        self.partida.dibujar(self.lienzo, self.t, self.f, self.record())

    def dibujar_pausa(self):
        s = self.lienzo
        self.dibujar_jugando()
        self.capa(200)
        self.titulo("PAUSA", NARANJA, 120)
        D.texto(s, "P / Esc: continuar      G: cambiar generadores      Q: abandonar", self.f["m"], TEXTO,
                centro=(ANCHO // 2, 172))
        enemigos = [("Murciélago", "vuela en direcciones aleatorias"),
                    ("Serpiente zombi", "deambula; 35 % de las veces te persigue"),
                    ("Mano de esqueleto", "sale del piso tras un aviso de 1 segundo"),
                    ("Serpiente sombra", "en la oscuridad; 55 % de las veces te persigue"),
                    ("Rey esqueleto", "se enfurece en momentos aleatorios"),
                    ("Víbora del nido", "40 % te persigue; huye si brillas con la fruta"),
                    ("Calavera flotante", "rebota por la cripta")]
        for i, (nom, desc) in enumerate(enemigos):
            D.texto(s, nom, self.f["m"], NARANJA, der=(300, 210 + i * 28))
            D.texto(s, desc, self.f["p"], TEXTO, pos=(320, 214 + i * 28))
        D.texto(s, f"Generadores en uso  ·  semilla {self.semilla_partida}", self.f["p"], TENUE,
                centro=(ANCHO // 2, 412))
        for i, (cat, nombre, _) in enumerate(CATEGORIAS):
            x = 70 + (i % 2) * 330
            y = 436 + (i // 2) * 24
            D.texto(s, f"{nombre.split(' ')[0]}: {NOMBRE_CORTO[self.clave_de(cat)]}", self.f["pp"],
                    (255, 210, 90), pos=(x, y))

    def dibujar_victoria(self):
        s = self.lienzo
        p = self.partida
        self.dibujar_jugando()
        self.capa(215)
        self.titulo("¡ESCAPASTE DE LA ISLA!", (140, 255, 220), 150)
        D.texto(s, f"Puntos: {p.puntos}", self.f["g"], TEXTO, centro=(ANCHO // 2, 220))
        if p.premio_final:
            D.texto(s, f"Bono sorteado por el generador: +{p.premio_final * 100} puntos", self.f["m"],
                    (255, 210, 60), centro=(ANCHO // 2, 270))
        elif p.nivel == 4:
            D.texto(s, "Sin la llave calavera la cripta quedó cerrada... ¿la buscarás la próxima vez?",
                    self.f["p"], (200, 120, 255), centro=(ANCHO // 2, 270))
        D.texto(s, "Enter: continuar", self.f["m"], TENUE, centro=(ANCHO // 2, 400))

    def dibujar_gameover(self):
        s = self.lienzo
        p = self.partida
        D.calavera(s, ANCHO // 2, 130, 4.0, col=(220, 215, 200), ojos=(120, 20, 30))
        self.titulo("FIN DEL JUEGO", (240, 80, 90), 230)
        D.texto(s, f"Puntos: {p.puntos}      Nivel alcanzado: {p.nivel_max}", self.f["m"], TEXTO,
                centro=(ANCHO // 2, 285))
        D.texto(s, "Enter: volver al menú", self.f["m"], TENUE, centro=(ANCHO // 2, 400))

    def dibujar_nombre(self):
        s = self.lienzo
        self.titulo("¡ENTRASTE AL TOP 10!", (255, 210, 60), 170)
        D.texto(s, f"{self.partida.puntos} puntos", self.f["g"], TEXTO, centro=(ANCHO // 2, 225))
        D.texto(s, "Escribe tu nombre y presiona Enter", self.f["m"], TENUE, centro=(ANCHO // 2, 285))
        caja = pygame.Rect(0, 0, 340, 54)
        caja.center = (ANCHO // 2, 345)
        pygame.draw.rect(s, NARANJA, caja, 2, border_radius=8)
        cursor = "_" if int(self.t * 2) % 2 == 0 else " "
        D.texto(s, self.entrada + cursor, self.f["g"], TEXTO, centro=caja.center)

    def dibujar_ranking(self):
        s = self.lienzo
        self.titulo("RANKING DE JUGADORES", NARANJA, 44)
        cols = [24, 60, 200, 290, 380, 500]
        for x, h in zip(cols, ["#", "Nombre", "Puntos", "Nivel", "Dificultad", "Generador"]):
            D.texto(s, h, self.f["p"], TENUE, pos=(x, 92))
        rk = self.datos["ranking"]
        if not rk:
            D.texto(s, "Todavía no hay puntajes. ¡El primero puede ser el tuyo!", self.f["m"], TEXTO,
                    centro=(ANCHO // 2, 260))
        for i, r in enumerate(rk):
            y = 125 + i * 38
            col = (255, 210, 60) if i == 0 else TEXTO
            nivel = "Cripta" if r["nivel"] == 5 else r["nivel"]
            for x, v in zip(cols, [i + 1, r["nombre"], r["puntos"], nivel, r["dificultad"], r.get("generador", "")]):
                D.texto(s, str(v), self.f["p"] if x == 500 else self.f["m"], col, pos=(x, y))
        D.texto(s, "Enter: volver", self.f["p"], TENUE, centro=(ANCHO // 2, ALTO - 22))

    def dibujar_ayuda(self):
        s = self.lienzo
        t = self.t
        self.titulo("CÓMO JUGAR", NARANJA, 40)
        D.texto(s, "Mueve la serpiente con las flechas (o WASD). Come dulces para crecer y completar",
                self.f["p"], TEXTO, centro=(ANCHO // 2, 78))
        D.texto(s, "cada nivel. Choques, mordidas y enemigos te quitan una vida.", self.f["p"], TEXTO,
                centro=(ANCHO // 2, 98))
        objetos = [(D.calabaza, "Calabaza: +10 puntos, creces 1 (se esfuma si tardas)"),
                   (D.caramelo, "Caramelo: +25 puntos, creces 2 (se esfuma si tardas)"),
                   (D.manzana_veneno, "Manzana envenenada: invierte los controles 4 s"),
                   (D.vela, "Vela (nivel 3): agranda tu luz"),
                   (D.llave_calavera, "Llave calavera (nivel 3): abre el nivel secreto"),
                   (D.fruta_carmesi, "Fruta carmesí (nivel 4): por unos segundos puedes devorar víboras"),
                   (D.alma, "Alma (cripta): +30 puntos; se esfuma y reaparece")]
        for i, (fn, txt) in enumerate(objetos):
            fn(s, (2, 4.6 + i * 1.55), t)
            D.texto(s, txt, self.f["p"], TEXTO, pos=(84, HUD + int((4.6 + i * 1.55) * 24) + 4))
        D.texto(s, "Etapas: 1 Cementerio · 2 Barco · 3 Mansión · 4 Nido de serpientes · ? Cripta secreta",
                self.f["p"], NARANJA, centro=(ANCHO // 2, ALTO - 84))
        D.texto(s, "Supervivencia: niveles al azar, uno tras otro, hasta perder todas las vidas",
                self.f["p"], NARANJA, centro=(ANCHO // 2, ALTO - 60))
        D.texto(s, "P: pausa · M: sonido" + ("" if WEB else " · F11: pantalla completa") + " · Enter: volver", self.f["p"], TENUE,
                centro=(ANCHO // 2, ALTO - 30))


if __name__ == "__main__":
    App().ejecutar()
    sys.exit()
